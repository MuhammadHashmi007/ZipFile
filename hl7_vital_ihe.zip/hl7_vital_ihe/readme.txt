hl7_vital_ihe logic
===================
HL7 IHE Integrating the Healthcare Enterprise

=== main::main ===
Create log folder
Check that only one instance of the program is runnig
Read configuration
Create folder to move files when sending fails
Starts a loop to monitor for folders
    === sckProc::sendProc ===
    Get folders from configuration 
    Connect to remote server using TCP
    Get patient info from file
    Get more patient info from a SQL database ???
    Convert patient info from XML to HL7
    Send the information to remote server
    Receive reply (in case of error move to fail folder)
    Delete the file
Delete the folder

Dependencies
============
This package needs the following dependencies
- firebird-dev
- libfbclient.so (libgds.so was its older name)

Configuration
=============
Pub_database: Firebird database
Destination_Host: Host to send HL7 messages
Destination_Port: Port to send HL7 messages
Socket_Timeout_Sec: Timeout of the socket
XML_Storing_Days: Number of days to keep XML files
SOM_Charactor: Character to delimit SOM
EOM_Charactor: Character to delimit EOM
Send_Wait_Sec
XML_Directory
WORK_Directory
FAIL_Directory

These parameters affect how the HL7 messages are filled

-- [MSH Segment] --
Sending_Application
Sending_Facility
Receiving_Application
Receiving_Facility
Accept_Acknowledgment_Type
Application_Acknowledgment_Type
Country_Code
Character_Set
Principal_Language
Message_Profile_Identifier

-- [PID Segment] --
Patient_ID_List
Patient_Name
Invert_Name

-- [PV1 Segment] --
PV1_Segment

-- [ORC Segment] --
ORC_Segment

-- [OBR Segment] --"
Filler_Order_Number
Universal_Service_ID

-- [TQ1 Segment] --
TQ1_Segment

-- [ACK Segment] --
ACK_Ignore_Message_Type

Most important modules
======================
Module main
***********
 Function name: check_instance ()
 Description: Checks is there is some other instance for the
 application runing
 Arguments: (IN /) void
 Return value: void

 Function name: main ()
 Description: Main
 Arguments: (IN /) int args: Number of execution arguments
(IN /) char * argv []: execution argument
 Return value: int

Module sckProc
**************
 Function name: sckProc ()
 Description: Constructor
 Arguments: None
 Return value: None

 Function name: sendProc ()
 Description: Transmission reception processing
 Argument: t_dirinfo * p_dinfo: transmission directory information
 Return value: int 0: Success 1: Error

 Function name: getXmlData ()
 Description: Acquire transmission data from file
 Arguments: char * p_fname: File
     std::string * p_sdata: transmission data
 Return value: int 0: success -1: error

 Function name: getfilesize ()
 Description: Get file size
 Arguments: char * p_fname: File
 Return value: long file size

 Function name: onePatiProc ()
 Description: One patient's treatment
 Argument: const char * p_fname: transmission message file name (used for log output)
     std::string * p_sdata: transmission message
 Return value: int 0: Normal minus: Error code

 Function name: moveFileFailDir ()
 Description: Move the file to the fail directory
 Arguments: const char * p_dname: The directory where the file before the move was located
     const char * p_fname: file (full path)
 Return value: None

 Function name: checkRecvPack ()
 Description: Check received message
 Argument: std :: string * p_sendstr: transmission message
     std::string * p_recvstr: received message
     const char * p_fname: xml file name
 Return value: int 0: OK -1: Error

 Function name: get1Segment ()
 Description: Extract one segment of telegram from HL7 telegram
 Argument: std :: string * p_1_seg: 1 segment
     std::string * p_hl 7: HL 7 message
     std::string * p_key: Segment key (such as MSH)
 Return value: None

 Function name: get1data ()
 Description: Extract one data of one segment.
 Argument: std::string * p_data: extracted data
     std::string * p_1_seg: 1 segment
     int pos: position of data
 Return value: None

 Function name: getSeqId ()
 Description: Obtain serial number and sequence number of message control ID
 Argument: int * p_dataid: The acquired serial number
     unsigned long * p_dataseq: Number acquired
 Return value: None

Module convHL7fromXML
*********************
 Function name: convHL7fromXML ()
 Description: Constructor
 Arguments: None
 Return value: None

 Function name: convHL7 ()
 Description: Convert XML to HL7
 Arguments: string xml: XML
     unsigned long: Serial number to be used in HL7 message
         Increment done outside of this class
     int msgidnum: Sequence number to be used for message control ID
         Increment done outside of this class
     vector <t_prminfo> * p_prmlist: parameter list
     vector <t_untinfo> * p_untlist: unit list
 Returns: string HL7 data string

 Function name: getPtInfo ()
 Description: Extract patient information from XML and store it in structure
 Arguments: string xml: XML
     t_ptinfo * p_ptinfo: For acquiring patient information
 Return value: None

 Function name: getMeasInfo ()
 Description: Extract measured value information from XML and store it in list
 Arguments: string xml: XML
     vector <t_measinfo> * p_measlist: measured value information list
     vector <t_prminfo> * p_prmlist: parameter list
     vector <t_untinfo> * p_untlist: unit list
 Return value: None

 Function name: getTagData ()
 Description: Retrieve data from between tags
 Arguments: string xml: XML
     string tagstr: tag
     char *p_data: For storage of fetched data
     string::size_type datasize: data size used in error check
 Return value: None

 Function name: getTagData ()
 Description: Retrieve data from between tags
 Arguments: string xml: XML
     string tagstr: tag
     string * p_data: For retrieving the retrieved data
 Return value: None

 Function name: replaceSpecialChar ()
 Description: Replace non standard ASCII chars (UTF) in a
     string
 Argument: string * p_data: string without special chars
     string str: string with special chars to be replaced
 Return value: None

 Function name: setName () 
 Description: Separate name string from first name, last name, first name, second name
 Argument: t_ptinfo * p_ptinfo: patient information structure
     string name: name (before disassembly)
 Return value: None

 Function name: getUnitName ()
 Description: Acquire unit name.
 Argument: char * p_untidstr: unit ID
     char * p_data: For data set
     vector <t_untinfo> * p_untlist: unit list
 Return value: None

 Function name: getParamCode ()
 Description: Get the parameter name.
 Arguments: string prmtagstr: Parameter tag
     char * p_data: For data set
     vector <t_prminfo> * p_prmlist: parameter list
 Return value: None

 Function name: getTagDataMeas ()
 Description: Measurement value, unit, label, measurement date and time from 1 parameter XML
     I pulled it out and set it in the structure.
     Extract only the parameter name from the tag and set it in the structure.
 Argument: t_measinfo * p_meas: For storing measured value information
     string string: XML
     string tagstr: tag
     vector <t_untinfo> * p_untlist: unit list
     vector <t_prminfo> * p_prmlist: parameter list
 Return value: None

 Function name: getTimeZoneStr ()
 Description: Get the time zone.
 Argument: char * p_timezone: For data set
     string string: XML
 Return value: None
 
 Function name: getTimeStr ()
 Description: Obtain measurement date and time.
 Arguments: char * p_time for data set
     string string: XML
 Return value: None

 Function name: checkTag ()
 Description: Check whether the tag is ON in the setting file
 Returns true if it is * ON
 Argument: string tagstr: tag
     vector <t_prminfo> * p_prmlist: parameter list
 Return value: None

 Function name: setPrmCount ()
 Description: Set the counter for discontinuous parameters.
 Arguments: t_measinfo * p_meas: 1 Parameter structure
     vector <t_measinfo> * p_measlist: parameter list
 Return value: None

 Function name: convTimeStr ()
 Description: Delete "/", "", ":" in the date and time data
 Arguments: string & string: date / time data string
 Return value: None

