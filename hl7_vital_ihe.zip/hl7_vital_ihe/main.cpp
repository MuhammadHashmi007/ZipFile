#include <iostream>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <sys/types.h>
#include <sys/sem.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>

#include "logwrite.h"
#include "confread.h"
#include "cmdDir.h"
#include "sckProc.h"
#include "timer.h"
#define _PATH_RELATE
#include "path_relate.h"

// version information
#define VITAL_DRV_PRG_NM    "hl7_vital_ihe"
#define VITAL_DRV_EXE_NO    101 // copy hl7_vital_gw and remodel it for ihe

// -----------------------------------------------
// external variable
// -----------------------------------------------
void SignalHandler(int sig);
bool G_signal2_flag = false; // Signal 2 flag

char G_exe_name[64];

//////////////////////////////////////////////////
//
// About double launch
//
//////////////////////////////////////////////////
#define CHK_INSTANCE_OK 0
#define CHK_INSTANCE_NG -1
#define CHK_INSTANCE_DUP -2
/**************************************************************
* Function name: check_instance ()
* Description: Checks is there is some other instance for the 
*     application runing
* Arguments: (IN /) void
* Return value: void
**************************************************************/
int check_instance()
{
	union semun
	{
		int val;
		struct semid_ds* buf;
		unsigned short* array;
		struct seminfo* __buf;
	};
	
	key_t ipc_key;
	int sem_id;
	sembuf sops;
	semun sem_arg;
	int err = 0;
	
	// Acquire the full path of this program
	char prg_path[256];
	memset( prg_path, 0 , sizeof(prg_path) );
	readlink( "/proc/self/exe", prg_path, sizeof(prg_path) );
	
	if( !err ) {
		//ipc_key = ftok(EXE_FILE_PATH ,1);
		ipc_key = ftok( prg_path, 1 );
		if( ipc_key == -1 ) err = CHK_INSTANCE_NG;
	}
	// Acquire the semaphore ID
	if( !err ) {
		sem_id = semget( ipc_key, 1, 0777 );
		if( sem_id == -1 ) {
			// Create a new semaphore
			sem_id = semget( ipc_key, 1, 0777 | IPC_CREAT | IPC_EXCL );
			if( sem_id == -1 ) err = CHK_INSTANCE_NG;
			if( !err ) {
				sem_arg.val = 1;
				if( semctl( sem_id, 0, SETVAL, sem_arg ) == -1 ) err = CHK_INSTANCE_NG;
			}
		}
	}
	// Acquire a semaphore
	if( !err ) {
		sops.sem_num = 0;
		sops.sem_op = -1;
		sops.sem_flg = SEM_UNDO | IPC_NOWAIT;
		if( semop( sem_id, &sops, 1 ) == -1 ) err = CHK_INSTANCE_DUP;
	}
	
	//if( err == CHK_INSTANCE_DUP ) cout << "monevt_save already running.\n";
	return err;
}


/**************************************************************
* Function name: main ()
* Description: Main
* Arguments: (IN /) int args: Number of execution arguments
*     (IN /) char * argv []: execution argument
* Return value: int
**************************************************************/
int main(int args, char *argv[])
{

	// Acquire the full path of this program
	char prg_path[256];
	memset( prg_path, 0 , sizeof(prg_path) );
	readlink( "/proc/self/exe", prg_path, sizeof(prg_path) );


	memset( G_exe_name, 0, sizeof(G_exe_name) );
	strcpy( G_exe_name, path_find_filename( prg_path ));

	logwrite logdat( G_exe_name );
	char logbuf[256];
	std::vector<t_dirinfo> dirlist;
	timer tmw;

	//-----------------------------------------------------------------------
	// startup process
	//-----------------------------------------------------------------------
	// ----------------------------------------- Create log directory -------
	mkdir(LOG_DIR, ACCESSPERMS);

	// Create log directory
	logdat.trace_log( __func__, __LINE__, "START" );

	logdat.job_log("------------------------------------------------");
	sprintf(logbuf, " %s Ver:%d BUILD:%s %s", VITAL_DRV_PRG_NM, VITAL_DRV_EXE_NO, C_DATE, C_TIME);
	logdat.job_log(logbuf);
	logdat.job_log("------------------------------------------------");
	logdat.trace_log( __func__, __LINE__, "mkdir(LOG_DIR, ACCESSPERMS)" );

	// ----------------------- Prevention of double launch with semaphore ---
	int ret;
	// Prevent duplicate activation
	ret = check_instance();
	if( ret == CHK_INSTANCE_DUP ) {
		logdat.job_log( "Duplicate check error...program end." );
		return 0;
	}
	else if( ret == CHK_INSTANCE_NG ) {
		logdat.job_log( "Semaphore error...program end." );
		return 0;
	}

	confread confrdat( G_exe_name );
	// ------------------------------------------ Read configuration file ---
	confrdat.vitalConf();
	logdat.trace_log( __func__, __LINE__, "confrdat.vitalConf()" );
	
	sckProc sproc( &confrdat, G_exe_name );

	logdat.job_log("--- READ CONFIG ---");

	logdat.job_log("-- [Common] -- ");
	sprintf(logbuf, "pub_database:[%s] ",          confrdat.m_pub_database.c_str() );     logdat.job_log(logbuf);
	sprintf(logbuf, "Destination_Host:[%s] ",      confrdat.m_destination_host.c_str() ); logdat.job_log(logbuf);
	sprintf(logbuf, "Destination_Port:[%d] ",      confrdat.m_destination_port );         logdat.job_log(logbuf);
	sprintf(logbuf, "Socket_Timeout_Sec:[%d] SEC", confrdat.m_socket_timeout_sec );       logdat.job_log(logbuf);
	sprintf(logbuf, "XML_Storing_Days:[%d] DAY",   confrdat.m_storing_days );             logdat.job_log(logbuf);
	sprintf(logbuf, "SOM_Charactor:[%s]",          confrdat.m_som_char.c_str() );         logdat.job_log(logbuf);
	sprintf(logbuf, "EOM_Charactor:[%s]",          confrdat.m_eom_char.c_str() );         logdat.job_log(logbuf);
	sprintf(logbuf, "Send_Wait_Sec:[%d] SEC",      confrdat.m_send_wait_sec );            logdat.job_log(logbuf);
	sprintf(logbuf, "XML_Directory:[%s]",          confrdat.m_xml_dir.c_str() );          logdat.job_log(logbuf);
	sprintf(logbuf, "WORK_Directory:[%s]",         confrdat.m_workdir.c_str() );          logdat.job_log(logbuf);
	sprintf(logbuf, "FAIL_Directory:[%s]",         confrdat.m_faildir.c_str() );          logdat.job_log(logbuf);

	logdat.job_log("-- [MSH Segment] --");
	sprintf(logbuf, "Sending_Application:[%s]",             confrdat.m_send_application.c_str()); logdat.job_log(logbuf);
	sprintf(logbuf, "Sending_Facility:[%s]",                confrdat.m_send_facility.c_str());    logdat.job_log(logbuf);
	sprintf(logbuf, "Receiving_Application:[%s]",           confrdat.m_rcv_application.c_str());  logdat.job_log(logbuf);
	sprintf(logbuf, "Receiving_Facility:[%s]",              confrdat.m_rcv_facility.c_str());     logdat.job_log(logbuf);
	sprintf(logbuf, "Accept_Acknowledgment_Type:[%s]",      confrdat.m_accept_acknow.c_str());    logdat.job_log(logbuf);
	sprintf(logbuf, "Application_Acknowledgment_Type:[%s]", confrdat.m_app_acknow.c_str());       logdat.job_log(logbuf);
	sprintf(logbuf, "Country_Code:[%s]",                    confrdat.m_country_code.c_str());     logdat.job_log(logbuf);
	sprintf(logbuf, "Character_Set:[%s]",                   confrdat.m_char_set.c_str());         logdat.job_log(logbuf);
	sprintf(logbuf, "Principal_Language:[%s]",              confrdat.m_pri_language.c_str());     logdat.job_log(logbuf);
	sprintf(logbuf, "Message_Profile_Identifier:[%s]",      confrdat.m_msg_profile_id.c_str());   logdat.job_log(logbuf);

	logdat.job_log("-- [PID Segment] --");
	sprintf(logbuf, "Patient_ID_List:[%s]", confrdat.m_patient_id_list.c_str()); logdat.job_log(logbuf);
	sprintf(logbuf, "Patient_Name:[%s]",    confrdat.m_patient_name.c_str());    logdat.job_log(logbuf);
	sprintf(logbuf, "Invert_Name:[%s]",     confrdat.m_inv_name.c_str());        logdat.job_log(logbuf);

	logdat.job_log("-- [PV1 Segment] --");
	sprintf(logbuf, "PV1_Segment:[%s]", confrdat.m_pv1_seg.c_str()); logdat.job_log(logbuf);

	logdat.job_log("-- [ORC Segment] --");
	sprintf(logbuf, "ORC_Segment:[%s]", confrdat.m_orc_seg.c_str()); logdat.job_log(logbuf);

	logdat.job_log("-- [OBR Segment] --");
	sprintf(logbuf, "Filler_Order_Number:[%s]",  confrdat.m_filler_order_num.c_str()); logdat.job_log(logbuf);
	sprintf(logbuf, "Universal_Service_ID:[%s]", confrdat.m_univ_service_id.c_str());          logdat.job_log(logbuf);

	logdat.job_log("-- [TQ1 Segment] --");
	sprintf(logbuf, "TQ1_Segment:[%s]", confrdat.m_tq1_seg.c_str()); logdat.job_log(logbuf);

	logdat.job_log("-- [ACK Segment] --");
	sprintf(logbuf, "ACK_Ignore_Message_Type:[%s]", confrdat.m_ack_ignore_message_type.c_str()); logdat.job_log(logbuf);

	logdat.job_log("-- [OBX Segment] --");
	logdat.job_log("--- PARAMETER ------------");
	vector<t_prminfo>::iterator prm_pos;
	for( prm_pos = confrdat.m_prmList.begin(); prm_pos != confrdat.m_prmList.end(); prm_pos++ ) {
		sprintf(logbuf, "%s:%s", (*prm_pos).tag.c_str(), (*prm_pos).code.c_str());
		logdat.job_log(logbuf);
	}
	logdat.job_log("--- UNITS ----------------");
	vector<t_untinfo>::iterator unt_pos;
	for( unt_pos = confrdat.m_untList.begin(); unt_pos != confrdat.m_untList.end(); unt_pos++ ) {
		sprintf(logbuf, "Unit%2d:%s", (*unt_pos).id, (*unt_pos).name.c_str());
		logdat.job_log(logbuf);
	}
	
	// ------ Create a file move destination directory when sending fails ---
	mkdir(confrdat.m_faildir.c_str(), ACCESSPERMS);

	// -------------------------------- Declare directory operation class ---
	cmdDir cdir(confrdat.m_workdir.c_str(), confrdat.m_faildir.c_str());

	// ------------------------------------------ Register signal handler ---
	signal(SIGUSR2, SignalHandler);

	// -------------------------------------------------------- Main loop ---
	logdat.job_log("!!MAIN PROC START!!");
	while(true){

		// ------------------------------------
		// Save expired directory monitor & delete
		// ------------------------------------
		int delnum = cdir.deleteDirSaveDaysOver(confrdat.m_storing_days, confrdat.m_workdir.c_str());
		// Output log with deletion processing
		if(delnum > 0){
			sprintf(logbuf, "!!SAVE DAYS OVER!! RMDIR:%d, %s", delnum, confrdat.m_workdir.c_str());
			logdat.job_log(logbuf);
			logdat.tm_log(logbuf);
			logdat.trace_log( __func__, __LINE__, logbuf );
		}
		delnum = cdir.deleteDirSaveDaysOver(confrdat.m_storing_days, confrdat.m_faildir.c_str());
		if(delnum > 0){
			sprintf(logbuf, "!!SAVE DAYS OVER!! RMDIR:%d, %s", delnum, confrdat.m_faildir.c_str());
			logdat.job_log(logbuf);
			logdat.tm_log(logbuf);
			logdat.trace_log( __func__, __LINE__, logbuf );
		}

		// ------------------------------------
		// effective directory monitoring
		// ------------------------------------
		dirlist.clear();
		int dirnum = cdir.getDirList(&dirlist, confrdat.m_data_sort);
		
		if(dirnum > 0){
			// ------------------------------------
			// send process
			// ------------------------------------
			// Print the number of directories to the log
			sprintf(logbuf, "DIRECTORY:%d", dirnum);
			logdat.job_log(logbuf);
			logdat.tm_log(logbuf);
			logdat.trace_log( __func__, __LINE__, logbuf );

			std::vector<t_dirinfo>::iterator dir_pos;
			for( dir_pos = dirlist.begin(); dir_pos != dirlist.end(); dir_pos++ ) {

				if( sproc.sendProc(&(*dir_pos)) < 0){
					// Set a wait time of ** seconds in case of communication error
					sprintf(logbuf, "!!CONNECT ERR!! WAIT :60 sec");
					logdat.trace_log( __func__, __LINE__, logbuf );
					tmw.wait_proc( confrdat.m_socket_reconnect_sec, &G_signal2_flag);
					break;
				}
				// Set a wait time for each connection
				tmw.wait_proc(confrdat.m_send_wait_sec, &G_signal2_flag);
				sprintf(logbuf, "WAIT :%d sec", confrdat.m_send_wait_sec);
				logdat.trace_log( __func__, __LINE__, logbuf );
				// End with signal 2
				if(G_signal2_flag == true){
					break;
				}
			}
		}

		// End with signal 2
		if(G_signal2_flag == true){
			break;
		}

		tmw.wait_proc(confrdat.m_send_wait_sec, &G_signal2_flag);
		sprintf(logbuf, "WAIT :%d sec", confrdat.m_send_wait_sec);
		logdat.trace_log( __func__, __LINE__, logbuf );
	}

	dirlist.clear();
	logdat.job_log("--- DRIVER END ---");
	return 0;
}
/**************************************************************
* Function name: SignalHandler ()
* Description: Signal interrupt handler
* Argument: (IN /) int sig: Signal
* Return value: void
**************************************************************/
void SignalHandler(int sig)
{
	logwrite logdat(G_exe_name);
	char logbuf[256];
	memset(logbuf, 0, 256);
	sprintf(logbuf, "*** SIGNAL  %d ***", sig);
	logdat.job_log(logbuf);
	static bool b_signal = false;
	switch (sig){
	case SIGUSR2:
		if (b_signal) break; // make sure not to be nested
		b_signal = true;
		G_signal2_flag = true;
		break;
    }

}
