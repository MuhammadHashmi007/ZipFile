
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#include "cmdDir.h"

#define DIR_NAME_SIZE (12)
/**************************************************************
* Function name: cmdDir ()
* Description: Constructor
* Arguments: char * p_dname_w: xml file directory path
*     char * p_dname_f: xml file migration destination directory path
* Return value: None
***************************************************************/
cmdDir::cmdDir(const char *p_dname_w, const char *p_dname_f)
{
	m_xml_dir = p_dname_w;
}
/**************************************************************
* Function name: getDirList ()
* Description: getDirList Get sending effective directory list
* Argument std::vector <t_dirinfo> * p_dirlist: Directory list
* Returns: Number of directories in the directory
**************************************************************/
int cmdDir::getDirList(std::vector<t_dirinfo> *p_dirlist, int sort_sw)
{

	int dirnum = 0;

	// -----------------------------  Open CVWDB/vita directory ---
	DIR *dir_fp;
	dir_fp = opendir(m_xml_dir.c_str());
	if(dir_fp == NULL){
		return 0;
	}

	// --- Determine whether it is a vital directory and store it in the list ---
	struct  dirent *dirent_sts;
	while(true){
		dirent_sts = readdir(dir_fp);
		if(dirent_sts == NULL){
			break;
		}

		// Since . and .. are obviously out of scope, they are excluded
		if(strcmp(".", dirent_sts->d_name) == 0 || strcmp("..", dirent_sts->d_name) == 0){
			continue;
		}

		// Exclude except directories
		if(DT_DIR != dirent_sts->d_type){
			continue;
		}

		// check directory name
		if(!checkDirName(dirent_sts->d_name)){
			continue;
		}

		// set directory information
		t_dirinfo dirinfo;
		memset(&dirinfo, 0, sizeof(t_dirinfo));
		setDirInfo(dirent_sts->d_name, &dirinfo);

		// Add to list
		sortSetDirList(&dirinfo, p_dirlist, sort_sw);
		dirnum++;
	}

	// ----------------------------------------- Close directory ---
	closedir(dir_fp);

	return dirnum;
}
/**************************************************************
* Function name: deleteDirSaveDaysOver ()
* Description: Save expired directory delete
* Arguments int save_days: Number of days to keep
* Returns: Number of deleted directories
**************************************************************/
int cmdDir::deleteDirSaveDaysOver(int save_days, const char *p_dirname)
{	
	// If permanently saved if deletion days is 0, do not delete.
	if(save_days == 0){
		return 0;
	}

	int delnum = 0;
	m_save_days = save_days; // To use the number of saved days in another member function, copy it to a member variable

	// --------------------------------------- Open CVWDB/vita directory ---
	DIR *dir_fp;
	dir_fp = opendir(p_dirname);
	if(dir_fp == NULL){
		return 0;
	}

	// --- Determine whether it is a vital directory and store it in the list ---
	struct  dirent *dirent_sts;
	while(true){
		dirent_sts = readdir(dir_fp);
		if(dirent_sts == NULL){
			break;
		}

		// Since . and .. are obviously out of scope, they are excluded
		if(strcmp(".", dirent_sts->d_name) == 0 || strcmp("..", dirent_sts->d_name) == 0){
			continue;
		}

		// Exclude except directories
		if(DT_DIR != dirent_sts->d_type){
			continue;
		}

		// check directory name
		if(!checkDirName(dirent_sts->d_name)){
			continue;
		}

		// Check if it is expired
		if(!checkDirSaveDaysOver(dirent_sts->d_name)){
			continue;
		}

		// Delete directory
		deleteDir(dirent_sts->d_name, p_dirname);
		delnum++;
	}

	// --------------------------------------- Close directory ---
	closedir(dir_fp);

	return delnum;
}
/**************************************************************
* Function name: getFileList ()
* Description: Get file list of designated directory
* Argument: char * p_dname: directory
*     std::vector <std::string> * p_flist file list
* Return value: number of int files
**************************************************************/
int cmdDir::getFileList(const char *p_dname, std::vector<std::string> *p_flist)
{
	int filenum = 0;
	// Open directory
	DIR *dir_fp;

	dir_fp = opendir(p_dname);
	if(dir_fp == NULL){
		return 0;
	}

	struct  dirent *dirent_sts;
	while(true){
		dirent_sts = readdir(dir_fp);
		if(dirent_sts == NULL){
			break;
		}

		// . and .. are clearly excluded
		if(strcmp(".", dirent_sts->d_name) == 0 || strcmp("..", dirent_sts->d_name) == 0){
			continue;
		}

		// Except for files excluded (normally not possible)
		if(DT_REG != dirent_sts->d_type){
			continue;
		}

		std::string fname = "";
		fname = p_dname;
		fname += "/";
		fname += dirent_sts->d_name;
		sortSetFileList(&fname, p_flist);
		filenum++;
	}

	// Close the directory
	closedir(dir_fp);
	return filenum;
}
/**************************************************************
* Function name: checkDirName ()
* Description: Determine whether directory name is valid
*     Check if it is YYYYMMDDhhmm_YYYYMMDDhhmm (25 characters)
*     However, checking the year, month, day, hour, minute and second is easy.
* Argument const char * p_dnmae: Directory name
* Return value: bool true: enabled false: invalid
**************************************************************/
bool cmdDir::checkDirName(const char *p_dnmae)
{
	// check size (12 characters)
	if(strlen(p_dnmae) != DIR_NAME_SIZE){
		return false;
	}

	// check the year, month, day, hour, minute and second LAN time
	for(int i=0; i<DIR_NAME_SIZE; i++){
		if(p_dnmae[i] < '0' || p_dnmae[i] > '9'){
			return false;
		}
	}

	return true;
}
/**************************************************************
* Function name: setDirInfo ()
* Description: Information is set from the directory name to the structure
* Arguments const char * p_dname: Directory name
*     t_dirinfo * p_info: directory information
* Return value: None
**************************************************************/
void cmdDir::setDirInfo(const char *p_dname, t_dirinfo *p_info)
{

	// full path
	sprintf(p_info->full_path, "%s/%s", m_xml_dir.c_str(), p_dname);

	// LAN time
	memcpy(p_info->lan_time, p_dname, 12);
}
/**************************************************************
* Function name: sortSetDirInfo ()
* Description: Sort by file name and set to vector
* Arguments t_dirinfo * p_dinfo: Directory information
*     std::vector <t_dirinfo> * p_dirlist: directory information list
*     int sort _ sw: Sort method 0: Ascending order 1: Descending order
* Return value: None
**************************************************************/
void cmdDir::sortSetDirList(t_dirinfo *p_dinfo, std::vector<t_dirinfo> *p_dirlist, int sort_sw)
{

	std::string timeStr = p_dinfo->lan_time;
	std::vector<t_dirinfo>::iterator dir_pos;
	for( dir_pos = p_dirlist->begin(); dir_pos != p_dirlist->end(); dir_pos++ ) {
		std::string listTime = ((*dir_pos).lan_time);

		if(sort_sw == 0 && timeStr < listTime){
			p_dirlist->insert(dir_pos, *p_dinfo);
			return;
		}

		if(sort_sw == 1 && timeStr > listTime){
			p_dirlist->insert(dir_pos, *p_dinfo);
			return;
		}

	}
	p_dirlist->push_back(*p_dinfo);
}
/**************************************************************
* Function name: sortSetDirInfo ()
* Description: Sort by file name and set to vector
* Arguments std::string * p_fname: Filename
*     std::vector <std::string> * p_flist: file name list
* Return value: None
**************************************************************/
void cmdDir::sortSetFileList(std::string *p_fname, std::vector<std::string> *p_flist)
{

	std::vector<std::string>::iterator f_pos;
	for( f_pos = p_flist->begin(); f_pos != p_flist->end(); f_pos++ ) {

		if(*p_fname < (*f_pos)){
			p_flist->insert(f_pos, *p_fname);
			return;
		}
	}
	p_flist->push_back(*p_fname);
}
/**************************************************************
* Function name: checkDirSaveDaysOver ()
* Description: Check if the directory name has expired
*     Compare directory creation date and time of server's current time and directory name
*     If the difference is larger than the number of days of retention, the storage expiration date
* Argument const char * p_dnmae: Directory name
* Return value: bool true: enabled false: invalid
**************************************************************/
bool cmdDir::checkDirSaveDaysOver(const char *p_dnmae)
{
	// ----------- Get transmission LAN time from directory name ---
	char time_char[13]; time_char[12] = 0;
	memcpy(time_char, p_dnmae, 12);

	char year_char[5]; year_char[4] = 0;
	char mon_char[3];  mon_char[2]  = 0;
	char day_char[3];  day_char[2]  = 0;
	char hour_char[3]; hour_char[2] = 0;
	char min_char[3]; min_char[2]   = 0;

	memcpy(year_char,  time_char,     4);
	memcpy(mon_char,  &time_char[ 4], 2);
	memcpy(day_char,  &time_char[ 6], 2);
	memcpy(hour_char, &time_char[ 8], 2);
	memcpy(min_char,  &time_char[10], 2);

	struct tm dirtm;
	memset(&dirtm, 0, sizeof(struct tm));

	dirtm.tm_year = atoi(year_char) - 1900;
	dirtm.tm_mon  = atoi(mon_char) - 1;
	dirtm.tm_mday = atoi(day_char);
	dirtm.tm_hour  = atoi(hour_char);
	dirtm.tm_min  = atoi(min_char);

	time_t dir_time = mktime(&dirtm);

	// ----------------------------------- Get current server time ---
	time_t now_time = time(NULL);

	// --------------------------------- ��¸�����ڤ줫�����å� ---
	if( (now_time - dir_time) > (m_save_days * 60 * 60 * 24) ){
		return true;
	}

	return false;
}
/**************************************************************
* Function name: deleteDir ()
* Description: Removed expired directory (production)
* Argument const char * p_dnmae: Directory name
* Return value: None
**************************************************************/
void cmdDir::deleteDir(const char *p_dnmae, const char *p_dirname)
{
	// ------------------------- Create the full path of the directory ---
	char full_path[128];
	sprintf(full_path, "%s/%s", p_dirname, p_dnmae);

	// --------------------------------- Delete files in the directory ---

	// �ǥ��쥯�ȥ�򥪡��ץ�
	DIR *dir_fp;
	dir_fp = opendir(full_path);
	if(dir_fp == NULL){
		return;
	}

	struct  dirent *dirent_sts;
	while(true){
		dirent_sts = readdir(dir_fp);
		if(dirent_sts == NULL){
			break;
		}

		// . and .. are obviously not eligible for deletion
		if(strcmp(".", dirent_sts->d_name) == 0 || strcmp("..", dirent_sts->d_name) == 0){
			continue;
		}

		// Except for files, not subject to deletion (normally not possible)
		if(DT_REG != dirent_sts->d_type){
			continue;
		}

		// Delete file
		char delfileName[128];
		sprintf(delfileName, "%s/%s", full_path, dirent_sts->d_name);
		unlink(delfileName);
	}

	// Close the directory
	closedir(dir_fp);

	// -------------------------------------------- Delete directory ---
	if(rmdir(full_path) < 0){
		// It is almost impossible if it can not be deleted by this procedure
		// Delete it with the command (rm - rf) if it can not be deleted.
		// Leave it if this is not good
		char cmdchar[128];
		sprintf(cmdchar, "rm -rf %s", full_path);
		system(cmdchar);
	}

}
