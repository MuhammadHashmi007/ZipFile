
#ifndef _CLASS_SCKPROC
#define _CLASS_SCKPROC

#include "cmdDir.h"
#include "v_socket.h"
#include "confread.h"

// ------------------------------------------------------
//  check on reception
// ------------------------------------------------------
#define RECV_OK       0
#define RECV_ERR_DATA -1
#define RECV_ERR_SOCKET  -999

class sckProc
{
public:
	sckProc( confread  *p_confrdt, const char *exe_name );
	int sendProc(const t_dirinfo *p_dinfo);
private:
	confread *m_p_confrdt;
	v_socket m_sck;
	int getXmlData(const char *p_fname, std::string *p_sdata);
	long getfilesize(const char *p_fname);

	int onePatiProc(const char *p_fname, std::string *p_sdata);
	void moveFileFailDir(const char *p_dname, const char *p_fname);
	unsigned long m_HL7seq;
	int m_msgidnum;
	char m_server_date[16];
	std::vector<t_prminfo> m_prmlist;
	std::vector<t_untinfo> m_untlist;
	int checkRecvPack(std::string *p_sendstr, std::string *p_recvstr, const char *p_fname);
	void get1Segment(std::string *p_1seg, std::string *p_hl7, const char *p_key);
	void get1data(std::string *p_data, std::string *p_1seg, int pos);
	void getSeqId(int *p_id, unsigned long *p_seq);
	
	std::vector<t_prminfo> m_prmList;
	std::vector<t_untinfo> m_untList;

	char m_exe_name[64];
};

#endif // _CLASS_SCKPROC
