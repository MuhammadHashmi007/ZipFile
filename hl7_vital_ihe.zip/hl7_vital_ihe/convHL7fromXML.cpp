
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "convHL7fromXML.h"
#include "logwrite.h"

#define XML_TAG_PTID			"<PTID>"
#define XML_TAG_NAME			"<NAME>"
#define XML_TAG_SEX				"<SEX>"
#define XML_TAG_BIRTH			"<BIRTH>"
#define XML_TAG_DEPARTMENT_ID	"<DEPARTMENT_ID>"
#define XML_TAG_DEPARTMENT_NM	"<DEPARTMENT_NM>"
#define XML_TAG_CENTER_NM		"<CENTER_NM>"
#define XML_TAG_BED_NM			"<BED_NM>"
#define XML_TAG_INTERVAL		"<INTERVAL>"
#define XML_TAG_DATA_TIME		"<DATA_TIME>"
#define XML_TAG_DST				"<DST>"
#define XML_TAG_DATA			"<DATA>"
#define XML_TAG_ENABLE			"<ENABLE>"
#define XML_TAG_PARAM			"<PARAM>"
#define XML_TAG_VALUE			"<VALUE>"
#define XML_TAG_UNIT_ID			"<UNIT_ID>"
#define XML_TAG_UNIT_NM			"<UNIT_NM>"

#define HL7_STR_MSH        "MSH"
#define HL7_STR_MSA        "MSA"
#define HL7_STR_PID        "PID"
#define HL7_STR_ORC        "ORC"
#define HL7_STR_OBR        "OBR"
#define HL7_STR_OBX        "OBX"
#define HL7_STR_l          "|"
#define HL7_STR_CR         "\r"

#define HL7_STR_MSG_TYPE   "ORU^R01^ORU_R01"
#define HL7_STR_VER        "2.6"
#define HL7_STR_ASCII      "ASCII"
#define HL7_STR_VITAL      "VITAL"
#define HL7_STR_NM         "NM"
#define HL7_STR_PL         "PL"
#define HL7_STR_F          "F"
#define HL7_STR_R          "R"
#define HL7_STR_RE         "RE"

// Special character code to be converted (2 byte character)
#define UTF8_1BYTE				'\xC3'     // 1byte��
#define UTF8_2BYTE_A_GRV		'\xA0'     // 2byte�� a�i�O���C���j
#define UTF8_2BYTE_O_GRV		'\xB2'     // 2byte�� o�i�O���C���j
#define UTF8_2BYTE_U_GRV		'\xB9'     // 2byte�� u�i�O���C���j
#define UTF8_2BYTE_E_GRV		'\xA8'     // 2byte�� e�i�O���C���j
#define UTF8_2BYTE_E_ACT		'\xA9'     // 2byte�� e�i�A�N�[�g�j
#define UTF8_2BYTE_I_GRV		'\xAC'     // 2byte�� i�i�O���C���j
// Character code after conversion (1 byte character)
#define ISOIEC_STR_A_GRV		'\xE0'     // a�i�O���C���j
#define ISOIEC_STR_O_GRV		'\xF2'     // o�i�O���C���j
#define ISOIEC_STR_U_GRV		'\xF9'     // u�i�O���C���j
#define ISOIEC_STR_E_GRV		'\xE8'     // e�i�O���C���j
#define ISOIEC_STR_E_ACT		'\xE9'     // e�i�A�N�[�g�j
#define ISOIEC_STR_I_GRV		'\xEC'     // i�i�O���C���j

static char utf8Tbl[] = {
	UTF8_2BYTE_A_GRV,
	UTF8_2BYTE_O_GRV,
	UTF8_2BYTE_U_GRV,
	UTF8_2BYTE_E_GRV,
	UTF8_2BYTE_E_ACT,
	UTF8_2BYTE_I_GRV,
};
#define UTF8_TBL_NUM sizeof(utf8Tbl)/sizeof(char)

static char isoiecTbl[] = {
	ISOIEC_STR_A_GRV,
	ISOIEC_STR_O_GRV,
	ISOIEC_STR_U_GRV,
	ISOIEC_STR_E_GRV,
	ISOIEC_STR_E_ACT,
	ISOIEC_STR_I_GRV,
};
#define ISOIEC_TBL_NUM sizeof(isoiecTbl)/sizeof(char*)


/**************************************************************
* Function name: convHL7fromXML ()
* Description: Constructor
* Arguments: None
* Return value: None
**************************************************************/
convHL7fromXML::convHL7fromXML(confread *p_confrdt, patient_query *p_pq,  const char *exe_name )
{
	mp_confrdt = p_confrdt;
	mp_pq = p_pq;
	strcpy( m_exe_name, exe_name );

	// ------------------------------- Time zone character string setting ---
	tzset();
	int hourdata =  timezone / 3600 ;
	int mindata =  (timezone / 60) -  (hourdata * 60);
	if(hourdata < 0){
		hourdata *= (-1);
	}
	if(mindata < 0){
		mindata *= (-1);
	}
	char tzchar[16];

	if(timezone == 0){
		sprintf(tzchar, "+%02d%02d", hourdata, mindata);
	}else if(timezone < 0){
		sprintf(tzchar, "+%02d%02d", hourdata, mindata);
	}else{
		sprintf(tzchar, "-%02d%02d", hourdata, mindata);
	}

	m_timezone_str_dst0 = tzchar;

	long timezone_dst1 = timezone - 3600;
	hourdata =  timezone_dst1 / 3600 ;
	mindata =  (timezone_dst1 / 60) -  (hourdata * 60);
	if(hourdata < 0){
		hourdata *= (-1);
	}
	if(mindata < 0){
		mindata *= (-1);
	}

	if(timezone_dst1 < 0){
		sprintf(tzchar, "+%02d%02d", hourdata, mindata);
	}else{
		sprintf(tzchar, "-%02d%02d", hourdata, mindata);
	}

	m_timezone_str_dst1 = tzchar;

}
/**************************************************************
* Function name: convHL7 ()
* Description: Convert XML to HL7
* Arguments: string xml: XML
*     unsigned long: Serial number to be used in HL7 message
*         Increment done outside of this class
*     int msgidnum: Sequence number to be used for message control ID
*         Increment done outside of this class
*     vector <t_prminfo> * p_prmlist: parameter list
*     vector <t_untinfo> * p_untlist: unit list
* Returns: string HL7 data string
**************************************************************/
string convHL7fromXML::convHL7(string xml, unsigned long seq, int msgidnum, vector<t_prminfo> *p_prmlist, vector<t_untinfo> *p_untlist)
{
	logwrite logdat( m_exe_name );
	char logbuf[256];

	// -----------------------------------
	// Get current time and time zone string
	// -----------------------------------
	char nowtime[64];
	memset(nowtime, 0, sizeof(nowtime));
	time_t t;
	time( &t );
	struct tm *tm_now;
	tm_now = localtime(&t);
	
	strftime( nowtime, 80, "%Y%m%d%H%M%S", tm_now);

	// -----------------------------------
	// Get the time zone
	// -----------------------------------
	char timezone[8];
	memset(timezone, 0, sizeof(timezone));
	if(tm_now->tm_isdst == 0){
		strncpy(timezone, m_timezone_str_dst0.c_str(), m_timezone_str_dst0.size());
	}else{
		strncpy(timezone, m_timezone_str_dst1.c_str(), m_timezone_str_dst1.size());
	}

	// -----------------------------------
	// Create message control ID string
	// -----------------------------------
	char msg_id_str[81];
	char num_str[6];
	strftime( msg_id_str, 80, "%Y%m%d", tm_now);
	sprintf(num_str, "%06d", msgidnum);
	strcat(msg_id_str, num_str);

	// -----------------------------------
	// Acquire patient information from XML
	// -----------------------------------
	t_ptinfo ptinfo;
	memset(&ptinfo, 0, sizeof(t_ptinfo));
	getPtInfo(xml, &ptinfo);

	// -----------------------------------
	// Obtain measured value information from XML
	// -----------------------------------
	vector<t_measinfo> measinfoList;
	getMeasInfo(xml, &measinfoList, p_prmlist, p_untlist);

	// -----------------------------------
	// sequence number
	// -----------------------------------
	char seqnum[16];
	memset(seqnum, 0, sizeof(seqnum));
	sprintf(seqnum, "%lu", seq);

	sprintf(logbuf, "SEQUENCE NUMBER:%s MESSAGE CONTROL ID:%s", seqnum, msg_id_str);
	logdat.job_log(logbuf);

	// -----------------------------------
	// Create patient ID list
	// -----------------------------------
	char patient_id_list[64];
	strcpy(patient_id_list, ptinfo.ptid);
	strcat(patient_id_list, mp_confrdt->m_patient_id_list.c_str());

	// -----------------------------------
	// Create Implementer Order Number
	// -----------------------------------
	char filler_order_num[128];
	strcpy(filler_order_num, msg_id_str);
	strcat(filler_order_num, mp_confrdt->m_filler_order_num.c_str());

	// -----------------------------------
	// Create HL7 message from patient information and measured value information
	// -----------------------------------
	string hl7str = "";

	hl7str += mp_confrdt->m_som_char;          // SOM

	hl7str += HL7_STR_MSH;                     //  MSH
	hl7str += HL7_STR_l;                       //  1 field delimiter
	hl7str += "^~\\&";                         //  2 encoded characters
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_send_application;  //  3 Sending application
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_send_facility;     //  4 sending facility
	hl7str += HL7_STR_l;                       //    delimiter 	
	hl7str += mp_confrdt->m_rcv_application;   //  5 receiving application
	hl7str += HL7_STR_l;                       //    delimiter   
	hl7str += mp_confrdt->m_rcv_facility;      //  6 Receiving facility
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += nowtime;                         //  7 Message date / time
	if( "true" != mp_confrdt->m_no_timezone_str ){
		hl7str += timezone;                    //    timezone
	}
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  8 Security (not used)
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += HL7_STR_MSG_TYPE;                //  9 Message type
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += msg_id_str;                      // 10 Message control ID
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += "P";                             // 11 Processing ID
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += HL7_STR_VER;                     // 12 version ID
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += seqnum;                          // 13 sequence number
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 14 continuation pointer (unused)
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_accept_acknow;     // 15 Accepted acknowledgment type
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_app_acknow;        // 16 application acknowledgment type
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_country_code;      // 17 Country code
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_char_set;          // 18 Character Set
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_pri_language;      // 19 Main language of the message
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 20 alternative character set manipulation method (unused)
	hl7str += HL7_STR_l;                       //    delimier
	hl7str += mp_confrdt->m_msg_profile_id;    // 21 Message profile identifier
	hl7str += HL7_STR_CR;       

	hl7str += HL7_STR_PID;                     //  PID
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  1 set ID (unused)
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  2 Patient ID (unused)
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += patient_id_list;                 //  3 patient ID list
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  4 Alternate Patient ID from ADT
	if( ptinfo.apid[0] != 0x0 ){
		hl7str += ptinfo.apid;
	}
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += &ptinfo.name[0][0];              //  5 patient's name (surname)
	if(ptinfo.name[1][0] != 0){
		hl7str += "^";
		hl7str += ptinfo.name[1];              //  5 Patient name (first name)
	}
	hl7str += mp_confrdt->m_patient_name;      //    string to append to the name of PID - 5
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  6 Mother's Mainden Name
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  7 Date/Time of Birth
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  8 Administrative Sex
	switch( ptinfo.sex[0] ){
	case 'F':
	case 'M':
	case 'O':
	case 'N':
		hl7str += ptinfo.sex;
		break;
	}
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  9 Patient Alias
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 10 Race
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 11 Patient Address
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 12 Country Code
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 13 Phone Number - Home
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 14 Phone Number - Business
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 15 Primary Language
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 16 Marital Status
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 17 Religion
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              // 18 Patient Account Number
	hl7str += ptinfo.apid;
	hl7str += HL7_STR_l;                       //    delimiter

	
	hl7str += HL7_STR_CR;                      // CR

	if( "true" == mp_confrdt->m_pv1_seg ){
		hl7str += "PV1";                       // PV1
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "1";                         //  1 Set ID
		hl7str += HL7_STR_l;                   //    delimiter
		                                       //  2 Patient Class
		if( ptinfo.apid[0] == 0x0 )	hl7str += ptinfo.apid;
		else							hl7str += "I";
		hl7str += HL7_STR_l;                   //    delimiter
											   //  3 Assigned Patient Location

		if( ptinfo.center_nm[0] != 0x0 ){
//		if( ptinfo.poc[0] != 0x0 ){
			hl7str += ptinfo.center_nm;	       //  1 Point of Care
//			hl7str += ptinfo.poc;			   //  1 Point of Care
		}
		hl7str += "^";                         //    caracter ^
		if( ptinfo.room[0] != 0x0 ){
				hl7str += ptinfo.room;		   //  2 Room
		}
		hl7str += "^";                         //    caracter ^

		if( ptinfo.bedid[0] != 0x0 ){
			hl7str += ptinfo.bedid;            //  3 Bed
		}else{
			hl7str += ptinfo.bed_nm;           //  3 Bed
		}
		
		hl7str += "^";                         //    caracter ^
		if( ptinfo.facility[0] != 0x0 ){
			hl7str += ptinfo.facility;         //  4 Facility
		}

//		hl7str += ptinfo.department_nm;
//		hl7str += "^";                         // U
                                               //	Room
//		hl7str += "^";                         // U
//		hl7str += ptinfo.bed_nm;               //	BED-ID
		
		hl7str += HL7_STR_CR;                  // CR
	}

	if( "true" == mp_confrdt->m_orc_seg ){
		hl7str += HL7_STR_ORC;                 // ORC
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_RE;                  //  1 order control
		hl7str += HL7_STR_CR;                  // CR
	}

	hl7str += HL7_STR_OBR;                     // OBR
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += "1";                             //  1 set ID
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  2 not used
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += filler_order_num;                //  3 Implementor order number
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += mp_confrdt->m_univ_service_id;   //  4 Inspection items County ID VITAL (fixed)
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  5 not used
	hl7str += HL7_STR_l;                       //    delimiter
//	hl7str += "";                              //  6 not used
	hl7str += HL7_STR_l;                       //    delimiter
	hl7str += ptinfo.data_time;                //  7 Inspection date (data time)
	if( "true" != mp_confrdt->m_no_timezone_str ){
		hl7str += ptinfo.timezone_str;         //    time zone value
	}
	hl7str += HL7_STR_CR;                      // CR

	if( 0 < mp_confrdt->m_tq1_seg.size() ){
		hl7str += mp_confrdt->m_tq1_seg;       // TQ1 Segment
		hl7str += HL7_STR_CR;                  // CR
	}

	vector<t_measinfo>::iterator m_pos;
	int setid = 1;
	
	// OBX MDS/VMD/CHAN information requested by Philips 3/4/2015
	if( "true" == mp_confrdt->m_mdsvmdchan ){
		char setid_str[16];
		sprintf(setid_str, "%d", setid);
		// OBX MDS
		hl7str += HL7_STR_OBX;                 // OBX
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += setid_str;                   //  1 set ID
		hl7str += HL7_STR_l;                   //    delimiter
//		hl7str += HL7_STR_NM;                  //  2 binary type
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "69965^MDC_DEV_MON_PHYSIO_MULTI_PARAM_MDS^MDC";                      //  3 items to be inspected
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "1.0.0.0";                   //  4 check sub ID
		hl7str += HL7_STR_l;                   //    delimier
//		hl7str += (*m_pos).unit_nm;            //  5 Inspection result value
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  6 units
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  7 unused
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  8 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  9 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 10 not used
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_F;                   // 11 Inspection result state
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 12 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 13 not used

		hl7str += HL7_STR_CR;                  // CR

		setid++;
		sprintf(setid_str, "%d", setid);

		// OBX VMD
		hl7str += HL7_STR_OBX;                 // OBX
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += setid_str;                   //  1 set ID
		hl7str += HL7_STR_l;                   //    delimiter
//		hl7str += HL7_STR_NM;                  //  2 binary type
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "70686^MDC_DEV_PRESS_BLD_NONINV_VMD^MDC";                      //  3 check items
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "1.1.0.0";                   //  4 Inspection sub ID
		hl7str += HL7_STR_l;                   //    delimiter
//		hl7str += (*m_pos).unit_nm;            //  5 Inspection result value
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  6 units
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  7 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  8 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  9 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 10 not used
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_F;                   // 11 Inspection result state
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 12 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 13 not used

		hl7str += HL7_STR_CR;                  // CR

		setid++;
		sprintf(setid_str, "%d", setid);

		// OBX CHAN
		hl7str += HL7_STR_OBX;                 // OBX
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += setid_str;                   //  1 set ID
		hl7str += HL7_STR_l;                   //    delimiter
//		hl7str += HL7_STR_NM;                  //  2 binary type
		hl7str += HL7_STR_l;                   //    delmiter
		hl7str += "70687^MDC_DEV_PRESS_BLD_NONINV_CHAN^MDC";                      //  3 check items
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "1.1.1.0";                   //  4 check sub ID
		hl7str += HL7_STR_l;                   //    delimiter
//		hl7str += "";                          //  5 Inspection result value
		hl7str += HL7_STR_l;                   //    delimiter
//		hl7str += (*m_pos).unit_nm;            //  6 units
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  7 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  8 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  9 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 10 not used
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_F;                   // 11 Inspection result state
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 12 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 13 not used
		
		hl7str += HL7_STR_CR;                  // CR

		setid++;
}

	int subid = 1;
	
	for( m_pos = measinfoList.begin(); m_pos != measinfoList.end(); m_pos++ ) {

		// Create set ID
		char setid_str[16];
		sprintf(setid_str, "%d", setid);

		// Create inspection item character string
		string prmstr = (*m_pos).prm_code;

		hl7str += HL7_STR_OBX;                 // OBX
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += setid_str;                   //  1 set ID
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_NM;                  //  2 binary type
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += prmstr;                      //  3 check items
		hl7str += HL7_STR_l;                   //    delimiter

		char subid_str[16];
		sprintf(subid_str, "1.1.1.%d", subid);
		hl7str += subid_str;                   //  4 check sub ID

//		if( string::npos == prmstr.find( HL7_STR_l, 0 ) ) {
//			hl7str += HL7_STR_l;               //    delimiter
//		}

		
		hl7str += HL7_STR_l;                   //    delimiter

		hl7str += (*m_pos).value;              //  5 Inspection result value
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += (*m_pos).unit_nm;            //  6 units
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  7 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  8 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  9 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      // 10 not used
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_F;                   // 11 Inspection result state
		if(ptinfo.data_time[0] != 0){
			hl7str += HL7_STR_l;               //    delimiter
			//	hl7str += "";                  // 12 not used
			hl7str += HL7_STR_l;               //    delimiter
			//	hl7str += "";                  // 13 not used
			hl7str += HL7_STR_l;               //    delimiter
			hl7str += ptinfo.data_time;        // 14 Date and time of discontinuous parameter
			if( "true" != mp_confrdt->m_no_timezone_str ){
				hl7str += ptinfo.timezone_str; //    time zone of data date and time of discontinuity parameter
			}
		}

		hl7str += HL7_STR_CR;                  // CR

		setid++;
		subid++;
	}

	// Optional OBX segment for Patient/Device location informaton (HIMSS 2015 Interoperability Showcase)
	if( "true" == mp_confrdt->m_location ){
		char setid_str[16];
		sprintf(setid_str, "%d", setid);

		hl7str += HL7_STR_OBX;                 // OBX
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += setid_str;                   //  1 set ID
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_PL;                  //  2 
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "258048^MDCX_EVT_LS_DEVICE^MDC";  //  3 Device/Patient Location

		hl7str += HL7_STR_l;                   //    delimiter

		char subid_str[16];
		sprintf(subid_str, "1.1.1.%d", subid);
		hl7str += subid_str;                   //  4 check sub ID
		
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += "^";                         //    element delimiter ^
		hl7str += "^";                         //    element delimiter ^
		hl7str += "^";                         //    element delimiter ^
		hl7str += mp_confrdt->m_send_facility; //    Facility Name
		hl7str += "^";                         //    element delimiter ^
		hl7str += "^";                         //    element delimiter ^
		hl7str += "^";                         //    element delimiter ^
		//hl7str += "";                        //    Building Name (within Facilty)
		hl7str += "^";                         //    element delimiter ^
		//hl7str += "";                        //    Floor Name
		hl7str += "^";                         //    element delimiter ^
		hl7str += ptinfo.department_nm;        //    Area Name
		hl7str += HL7_STR_l;                   //    element delimiter ^
		//	hl7str += "";                      //  5 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  6 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  7 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  8 not used
		hl7str += HL7_STR_l;                   //    delimiter
		//	hl7str += "";                      //  9 not used
		hl7str += HL7_STR_l;                   //    delimiter
		hl7str += HL7_STR_F;                   // 10 Inspection result state
		if(ptinfo.data_time[0] != 0){
			hl7str += HL7_STR_l;               //    delimiter
			//	hl7str += "";                  // 11 not used
			hl7str += HL7_STR_l;               //    delimiter
			//	hl7str += "";                  // 12 not used
			hl7str += HL7_STR_l;               //    delimiter
			hl7str += ptinfo.data_time;        // 13 Data of discontinuity parameter Date and time
			if( "true" != mp_confrdt->m_no_timezone_str ){
				hl7str += ptinfo.timezone_str; //    time zone of data date and time of discontinuity parameter
			}

		subid++;
		setid++;

		}

		hl7str += HL7_STR_CR;                  // CR	
	}
	
	hl7str += mp_confrdt->m_eom_char;          //  EOM
	return hl7str;
}

/**************************************************************
* Function name: getPtInfo ()
* Description: Extract patient information from XML and store it in structure
* Arguments: string xml: XML
*     t_ptinfo * p_ptinfo: For acquiring patient information
* Return value: None
**************************************************************/
void convHL7fromXML::getPtInfo(string xml, t_ptinfo *p_ptinfo)
{
	// ----------------------------------------------- Acquiring patient ID ---
	getTagData(xml, XML_TAG_PTID, p_ptinfo->ptid, sizeof(p_ptinfo->ptid));
	// ------------------------------------------------ Acquisition of name ---
	string namestr;
	getTagData(xml, XML_TAG_NAME, &namestr);
	setName(p_ptinfo, namestr);
	// ---------------------------------------------- Acquisition of gender ---
	getTagData(xml, XML_TAG_SEX, p_ptinfo->sex, sizeof(p_ptinfo->sex));
	// ------------------------------------------ Acquisition of birth date ---
	getTagData(xml, XML_TAG_BIRTH, p_ptinfo->birth, sizeof(p_ptinfo->birth));
	// ------------------------------------------------------ Department ID ---
	getTagData(xml, XML_TAG_DEPARTMENT_ID, p_ptinfo->department_id, sizeof(p_ptinfo->department_id));
	// ---------------------------------------------------- Department name ---
	getTagData(xml, XML_TAG_DEPARTMENT_NM, p_ptinfo->department_nm, sizeof(p_ptinfo->department_nm));
	// -------------------------------------------------------- Center name ---
	getTagData(xml, XML_TAG_CENTER_NM, p_ptinfo->center_nm, sizeof(p_ptinfo->center_nm));
	// ------------------------------------------------------- Floor number ---
	getTagData(xml, XML_TAG_BED_NM, p_ptinfo->bed_nm, sizeof(p_ptinfo->bed_nm));
	// ----------------------------------------------------------- interval ---
	getTagData(xml, XML_TAG_INTERVAL, p_ptinfo->interval, sizeof(p_ptinfo->interval));
	// ---------------------------------------------------------- Data time ---
	
	getDataTimeStr(p_ptinfo->data_time, xml);              // data time
	getTimeZoneStr(p_ptinfo->timezone_str, xml);           // timezone
	
	// Retrieve additional patient information from ADT feed in cvwpub.fdb
	if( mp_pq != NULL ){
		if( strlen( p_ptinfo->ptid ) > 1 ){
	//		patient_query db( mp_confrdt->m_pub_database );
			if( mp_pq->find_patient( p_ptinfo->ptid ) == 0 ){
				// Matching Patinet found
				strncpy( p_ptinfo->pvn, mp_pq->patient_pvn.c_str(), sizeof( p_ptinfo->pvn ) -1 );
				strncpy( p_ptinfo->pvn, mp_pq->patient_pvn.c_str(), sizeof( p_ptinfo->pvn ) -1 );
				strncpy( p_ptinfo->apid, mp_pq->patient_apid.c_str(), sizeof( p_ptinfo->apid ) -1 );
				strncpy( p_ptinfo->poc, mp_pq->patient_poc.c_str(), sizeof( p_ptinfo->poc ) -1 );
				strncpy( p_ptinfo->pclass, mp_pq->patient_pclass.c_str(), sizeof( p_ptinfo->pclass ) -1 );
				strncpy( p_ptinfo->room, mp_pq->patient_room.c_str(), sizeof( p_ptinfo->room ) -1 );
				strncpy( p_ptinfo->bedid, mp_pq->patient_bedid.c_str(), sizeof( p_ptinfo->bedid ) -1 );
				strncpy( p_ptinfo->facility, mp_pq->patient_facility.c_str(), sizeof( p_ptinfo->facility ) -1 );
			}

		}
	}
}
/**************************************************************
* Function name: getMeasInfo ()
* Description: Extract measured value information from XML and store it in list
* Arguments: string xml: XML
*     vector <t_measinfo> * p_measlist: measured value information list
*     vector <t_prminfo> * p_prmlist: parameter list
*     vector <t_untinfo> * p_untlist: unit list
* Return value: None
**************************************************************/
void convHL7fromXML::getMeasInfo(string xml, vector<t_measinfo> *p_measlist, vector<t_prminfo> *p_prmlist, vector<t_untinfo> *p_untlist)
{

	// ---------------------------------------------------
	// Extract the measured value information part (<PARAM> </ PARAM>) from XML
	// ---------------------------------------------------
	string prmstr = "";
	getTagData(xml, XML_TAG_PARAM, &prmstr);

	string::size_type now_pos = 0;
	string::size_type next_pos = 0;

	while(true){
		next_pos = prmstr.find("<", now_pos);
		if(next_pos == string::npos){
			break;
		}

		now_pos = next_pos;
		next_pos = prmstr.find(">", now_pos+1);
		if(next_pos == string::npos){
			break;
		}

		string tag = prmstr.substr(now_pos, next_pos - now_pos + 1);
		string tagbk = tag;
		tag.insert(1, "/");

		now_pos = next_pos;
		next_pos = prmstr.find(tag, now_pos+1);
		if(next_pos == string::npos){
			break;
		}

		string measdata = prmstr.substr(now_pos+1, next_pos - now_pos - 1);
		now_pos = next_pos + tag.size();

		if( checkTag(tagbk, p_prmlist) ){
			t_measinfo minfo;
			memset(&minfo, 0, sizeof(t_measinfo));
			getTagDataMeas(&minfo, measdata, tagbk, p_untlist, p_prmlist);

			// 
			if(minfo.meas_time[0] != 0){
				setPrmCount(&minfo, p_measlist);
			}

			p_measlist->push_back(minfo);
		}
		next_pos = prmstr.find(tag, now_pos+1);
	}

}
/**************************************************************
* Function name: getTagData ()
* Description: Retrieve data from between tags
* Arguments: string xml: XML
*     string tagstr: tag
*     char *p_data: For storage of fetched data
*     string::size_type datasize: data size used in error check
* Return value: None
**************************************************************/
void convHL7fromXML::getTagData(string xml, string tagstr, char *p_data, string::size_type datasize )
{
	string tagdata = "";
	string::size_type pos1, pos2;
	pos1 = xml.find(tagstr.c_str(), 0);

	int tagsize = tagstr.size();
	tagstr.insert(1, "/");
	if(pos1 != string::npos){
		pos2 = xml.find(tagstr.c_str(), pos1);
		if(pos1 != string::npos){
			tagdata = xml.substr(pos1+tagsize, pos2 - pos1 - tagsize);
		}
	}
	if(tagdata.size() < datasize){
		strncpy(p_data, tagdata.c_str(), tagdata.size());
	}
}
/**************************************************************
* Function name: getTagData ()
* Description: Retrieve data from between tags
* Arguments: string xml: XML
*     string tagstr: tag
*     string * p_data: For retrieving the retrieved data
* Return value: None
**************************************************************/
void convHL7fromXML::getTagData(string xml, string tagstr, string *p_data )
{
	string::size_type pos1, pos2;
	pos1 = xml.find(tagstr.c_str(), 0);

	int tagsize = tagstr.size();
	tagstr.insert(1, "/");
	if(pos1 != string::npos){
		pos2 = xml.find(tagstr.c_str(), pos1);
		if(pos1 != string::npos){
			*p_data = xml.substr(pos1+tagsize, pos2 - pos1 - tagsize);
		}
	}
}

/**************************************************************
* Function name: replaceSpecialChar ()
* Description: Replace non standard ASCII chars (UTF) in a 
*     string
* Argument: string * p_data: string without special chars
*     string str: string with special chars to be replaced
* Return value: None
**************************************************************/
void convHL7fromXML::replaceSpecialChar(string *p_data, string str)
{
	// original name string
	char namebuf[str.length() + 1];
	memset(namebuf, '\0', sizeof(namebuf));
	memcpy(namebuf, str.c_str(), str.length());

	// Create string
	char namedata[str.length() + 1];
	memset(namedata, '\0', sizeof(namedata));
	int cnt = 0;
	for(int i=0; i<(int)strlen(namebuf); i++){
		// Look up the character string by 1 byte at a time and look for the 1st byte character.
		// If there is a character, it judges whether it is a special character by looking at the next byte.
		if(namebuf[i] == UTF8_1BYTE){
			for(unsigned long ii=0; ii<UTF8_TBL_NUM; ii++){
				if(namebuf[i+1] == utf8Tbl[ii]){
					namedata[cnt] = isoiecTbl[ii];
					cnt++;
					i++;
					break;
				}
			}
		}else{
			namedata[cnt] = namebuf[i];
			cnt++;
		}
	}
	*p_data += namedata;
}
/**************************************************************
* Function name: setName ()
* Description: Separate name string from first name, last name, first name, second name
* Argument: t_ptinfo * p_ptinfo: patient information structure
*     string name: name (before disassembly)
* Return value: None
**************************************************************/
void convHL7fromXML::setName(t_ptinfo *p_ptinfo, string name)
{
	// --- ita replacement ---
	logwrite logdat( m_exe_name );
	string newstr = "";
	
	replaceSpecialChar(&newstr, name);
	logdat.trace_log( __func__, __LINE__, name.c_str() );
	logdat.trace_log( __func__, __LINE__, newstr.c_str() );
	name = "";
	name = newstr;
	// ------------------------
	// If there is a space delimiter, use leading and trailing strings.
	// Spaces are consecutive, regardless of how many spaces are delimited.
	// Example: AA ^ BB ^ CC ^^^^^ DD � AA ^ DD
	// If swapping first name is on, swap character string.
	// Example: AA ^ DD � DD ^ AA
	vector<string> namelist;
	// Store string in list with space delimiter
	string namebuf = "";
	for(unsigned int i=0; i<name.length(); i++){
		if(name.at(i) != ' '){
			namebuf += name.at(i);
		}else{
			if(namebuf.size()>0){
				namelist.push_back(namebuf);
				namebuf = "";
			}
		}
	}
	if(namebuf.size()>0){
		namelist.push_back(namebuf);
	}

	memset(&p_ptinfo->name, '\0', sizeof(&p_ptinfo->name));
	// unnamed case
	if(namelist.size() == 0){
		//  do nothing
	}else if(namelist.size() == 1){
		// In case of no delimiter
		string namestr = namelist.front();
		strcpy(&p_ptinfo->name[0][0], namestr.c_str());
	}else{
		// In case of delimiter
		if( "true" == mp_confrdt->m_inv_name){			// In case of turning on first name change
			string namestr2 = namelist.back();
			strcpy(&p_ptinfo->name[0][0], namestr2.c_str());
			string namestr1 = namelist.front();
			strcpy(&p_ptinfo->name[1][0], namestr1.c_str());
		}else{
			string namestr2 = namelist.back();
			strcpy(&p_ptinfo->name[1][0], namestr2.c_str());
			string namestr1 = namelist.front();
			strcpy(&p_ptinfo->name[0][0], namestr1.c_str());
		}
	}
}
/**************************************************************
* Function name: getUnitName ()
* Description: Acquire unit name.
* Argument: char * p_untidstr: unit ID
*     char * p_data: For data set
*     vector <t_untinfo> * p_untlist: unit list
* Return value: None
**************************************************************/
void convHL7fromXML::getUnitName(char *p_untidstr, char *p_data, vector<t_untinfo> *p_untlist)
{
	vector<t_untinfo>::iterator unt_pos;
	int untid = atoi(p_untidstr);
	
	memset(p_data, '\0', sizeof(*p_data));
	for( unt_pos = p_untlist->begin(); unt_pos != p_untlist->end(); unt_pos++ ) {
		if( (*unt_pos).id == untid ){
			if((*unt_pos).name.size() < 256){
				memcpy(p_data, (*unt_pos).name.c_str(), (*unt_pos).name.size());
			}else{
				memcpy(p_data, (*unt_pos).name.c_str(), 255);
			}
		}
	}

}
/**************************************************************
* Function name: getParamCode ()
* Description: Get the parameter name.
* Arguments: string prmtagstr: Parameter tag
*     char * p_data: For data set
*     vector <t_prminfo> * p_prmlist: parameter list
* Return value: None
**************************************************************/
void convHL7fromXML::getParamCode(string prmtagstr, char *p_data, vector<t_prminfo> *p_prmlist)
{
	vector<t_prminfo>::iterator prm_pos;
	// "<" ">"
	if(prmtagstr.find("<") != string::npos){
		prmtagstr.erase(prmtagstr.find("<"), 1);
	}
	if(prmtagstr.find(">") != string::npos){
		prmtagstr.erase(prmtagstr.find(">"), 1);
	}
	memset(p_data, '\0', sizeof(*p_data));
	for( prm_pos = p_prmlist->begin(); prm_pos != p_prmlist->end(); prm_pos++ ) {
		if( (*prm_pos).tag == prmtagstr){
			if((*prm_pos).code.size() < 256){
				memcpy(p_data, (*prm_pos).code.c_str(), (*prm_pos).code.size());
			}else{
				memcpy(p_data, (*prm_pos).code.c_str(), 255);
			}
		}
	}

}
/**************************************************************
* Function name: getTagDataMeas ()
* Description: Measurement value, unit, label, measurement date and time from 1 parameter XML
*     I pulled it out and set it in the structure.
* Extract only the parameter name from the tag and set it in the structure.
* Argument: t_measinfo * p_meas: For storing measured value information
*     string string: XML
*     string tagstr: tag
*     vector <t_untinfo> * p_untlist: unit list
*     vector <t_prminfo> * p_prmlist: parameter list
* Return value: None
**************************************************************/
void convHL7fromXML::getTagDataMeas(t_measinfo *p_meas, string xml, string tagstr, vector<t_untinfo> *p_untlist, vector<t_prminfo> *p_prmlist)
{
	getTagData(xml, XML_TAG_VALUE,     p_meas->value,     sizeof(p_meas->value));    // Measured value
	getTagData(xml, XML_TAG_UNIT_ID,   p_meas->unit_id,   sizeof(p_meas->unit_id));  // unit id
	getParamCode(tagstr, p_meas->prm_code, p_prmlist);                               // parameter name
	getUnitName(p_meas->unit_id, p_meas->unit_nm, p_untlist);                        // unit name
}
/**************************************************************
* Function name: getTimeZoneStr ()
* Description: Get the time zone.
* Argument: char * p_timezone: For data set
*     string string: XML
* Return value: None
**************************************************************/
void convHL7fromXML::getTimeZoneStr(char *p_timezone, string xml)
{
	string time_str = ""; // measurement date and time
	getTagData(xml, XML_TAG_DATA_TIME, &time_str);
	if( time_str.size() != 0 ){
		string dststr;
		getTagData(xml, XML_TAG_DST,  &dststr); // daylight saving time flag
		if(dststr == "1"){
			strncpy(p_timezone, m_timezone_str_dst1.c_str(), m_timezone_str_dst1.size());
		}else{
			strncpy(p_timezone, m_timezone_str_dst0.c_str(), m_timezone_str_dst0.size());
		}
	}
}

/**************************************************************
* Function name: getTimeStr ()
* Description: Obtain measurement date and time.
* Arguments: char * p_time for data set
*     string string: XML
* Return value: None
**************************************************************/
void convHL7fromXML::getDataTimeStr(char *p_time, string xml)
{
	int time_str_len = 14; // YYYYMMDDHHMMSS
	string time_str = "";  // measurement date and time
	getTagData(xml, XML_TAG_DATA_TIME, &time_str);
	
	if( time_str.size() != 0 ){
		strncpy(p_time, time_str.c_str(), time_str_len);
	}
}

/**************************************************************
* Function name: checkTag ()
* Description: Check whether the tag is ON in the setting file
* Returns true if it is * ON
*     Argument: string tagstr: tag
* vector <t_prminfo> * p_prmlist: parameter list
* Return value: None
**************************************************************/
bool convHL7fromXML::checkTag(string tagstr, vector<t_prminfo> *p_prmlist )
{
	vector<t_prminfo>::iterator prm_pos;
	for( prm_pos = p_prmlist->begin(); prm_pos != p_prmlist->end(); prm_pos++ ) {
		// "<" ">" Delete
		if(tagstr.find("<") != string::npos){
			tagstr.erase(tagstr.find("<"), 1);
		}
		if(tagstr.find(">") != string::npos){
			tagstr.erase(tagstr.find(">"), 1);
		}
		
		if( ((*prm_pos).tag == tagstr) && ((*prm_pos).code.length() != 0)){
			return true;
		}
	}
	return false;
}
/**************************************************************
* Function name: setPrmCount ()
* Description: Set the counter for discontinuous parameters.
* Arguments: t_measinfo * p_meas: 1 Parameter structure
*     vector <t_measinfo> * p_measlist: parameter list
* Return value: None
**************************************************************/
void convHL7fromXML::setPrmCount(t_measinfo *p_meas, vector<t_measinfo> *p_measlist)
{
	int now_count=0;

	vector<t_measinfo>::iterator m_pos;
	for( m_pos = p_measlist->begin(); m_pos != p_measlist->end(); m_pos++ ) {
		if( strcmp(p_meas->prm_code, (*m_pos).prm_code) == 0){
			now_count = atoi((*m_pos).count);
		}
	}

	sprintf(p_meas->count, "%d", now_count+1);
}
/**************************************************************
* Function name: convTimeStr ()
* Description: Delete "/", "", ":" in the date and time data
* Arguments: string & string: date / time data string
* Return value: None
**************************************************************/
void convHL7fromXML::convTimeStr(string &timestr)
{
	timestr.erase( 4,1);
	timestr.erase( 6,1);
	timestr.erase( 8,1);
	timestr.erase(10,1);
}

