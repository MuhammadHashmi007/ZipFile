
#include "prg_cmn.h"
#include "patient_query.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

patient_query::patient_query( string svnm )
{
	database_str = svnm;
	db_connect( database_str, NULL, NULL, DB_NOTRAN );
	
	patient_data = "";
	patient_query_status = PATIENT_QUERY_NOTFOUND;
}

patient_query::~patient_query()
{
	db_disconnect( NULL, NULL );
}

//	get text between sstr and estr
string patient_query::get_element( string str, char *sstr, char *estr )
{
	string retstr = "";
	std::size_t si = str.find( sstr, 0 );
	std::size_t ei = str.find( estr, 0 );
	
	if( si == std::string::npos || ei == std::string::npos )	return retstr;
	int spos = si + strlen( sstr );
	retstr = str.substr(spos, ei - spos);
	
	return retstr;
}

void patient_query::get_patient_data( string pd )
{
	
	patient_name = get_element( pd, "<Name>", "</Name>" );
	patient_kana = get_element( pd, "<NameKana>", "</NameKana>" );
	patient_sex = get_element( pd, "<Sex>", "</Sex>" );
	patient_bday = get_element( pd, "<Birth>", "</Birth>" );
	patient_pvn = get_element( pd, "<VisitNumber>", "</VisitNumber>" );
	patient_apid = get_element( pd, "<AltPID>", "</AltPID>" );
	patient_poc = get_element( pd, "<PointOfCare>", "</PointOfCare>" );
	patient_pclass = get_element( pd, "<PatientClass>", "</PatientClass>" );
	patient_room = get_element( pd, "<Room>", "</Room>" );
	patient_bedid = get_element( pd, "<BedID>", "</BedID>" );
	patient_facility = get_element( pd, "<Facility>", "</Facility>" );
}

int patient_query::find_patient( string pid )
{
	patient_query_status = PATIENT_QUERY_NOTFOUND;
	
	isc_tr_handle trans = NULL;
	int err = read_transaction( &trans );
	if( err ) return -1;
	
	isc_stmt_handle stmt = NULL;
	err = allocate_statement( &stmt );
	if( err ) {
		commit_transaction( &trans );
		return -1;
	}
	
	string sql;
	sql = "SELECT patient_data FROM patient WHERE patient_id='";
	sql = sql + pid;
	sql = sql + "' AND DEL_FLG=0";

	XSQLDA* sqlda;
	char blob_items[] = {
		isc_info_blob_max_segment, isc_info_blob_total_length
	};
	char res_buffer[32], *p, item;
	int blob_size = -1;
	int max_segment = -1;
	int field_cnt = 1;

	sqlda = (XSQLDA *)malloc( XSQLDA_LENGTH( field_cnt ));
	sqlda->sqln = field_cnt;
	sqlda->sqld = field_cnt;
	sqlda->version = 1;
	
	if( db_prepare( &trans, &stmt, sql, sqlda )) {
		free( sqlda );
		return -1;
	}
	
	ISC_QUAD blob_id;
	short iflg0 = 0;
	sqlda->sqlvar[0].sqldata = (char *)&blob_id;
	sqlda->sqlvar[0].sqltype = SQL_BLOB + 1;
	sqlda->sqlvar[0].sqllen = sizeof( ISC_QUAD );
	sqlda->sqlvar[0].sqlind = &iflg0;

	ISC_STATUS_ARRAY status;

	if( isc_dsql_prepare( status, &trans, &stmt, 0, (char *)sql.c_str(), 1, sqlda )) {
		free( sqlda );
		return -1;
	}
		
	isc_dsql_execute( status, &trans, &stmt, 1, NULL );
	if( status[0] == 1 && status[1] ) {
		// failed
		//*err = getSqlerrno();
	}
	else {
		// successfull
		long fetch_stat = isc_dsql_fetch( status, &stmt, 1, sqlda );
		if( fetch_stat != 0 ){
			free( sqlda );
			return -1;
		}
		isc_blob_handle blob_handle;
		blob_handle = NULL;
		isc_open_blob( status, &DB, &trans, &blob_handle, &blob_id );
		if( status[0] == 1 && status[1] ) {
			//*err = getSqlerrno();
			free( sqlda );
			return -1;
		}

		isc_blob_info( status, &blob_handle, sizeof(blob_items), blob_items, sizeof(res_buffer), res_buffer );
		if( status[0] == 1 && status[1] ) {
			//*err = getSqlerrno();
			free( sqlda );
			return -1;
		}else {
			short length;
			for( p = res_buffer; *p != isc_info_end; ) {
				item = *p++;
				length = (short)isc_vax_integer( p, 2 );
				p += 2;
				switch( item ) {
				case isc_info_blob_max_segment:
					max_segment = isc_vax_integer( p, length );
					break;
				case isc_info_blob_total_length:
					blob_size = isc_vax_integer( p, length );
					break;
				}
				p += length;
			}
		}
		char *getmem = new char[blob_size + 1];
		short blob_seg_len;
		long blob_stat;
		blob_stat = isc_get_segment( status, &blob_handle, (unsigned short *)&blob_seg_len, blob_size, getmem );
		isc_close_blob( status, &blob_handle );
		
		getmem[ blob_size ] = 0x0;
		patient_data = getmem;
		
		patient_id = pid;
		get_patient_data( patient_data );
		
		patient_query_status = PATIENT_QUERY_FOUND;

		//ret = getmem;
		delete[] getmem;
	}
	free( sqlda );
	
	return 0;
}


