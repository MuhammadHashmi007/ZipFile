
#include <iostream>
#include <pthread.h>
#include <time.h> 

#include "timer.h"

/**************************************************************
* Function name: wait_routine ()
* Description: Latency processing nanosleep
* Arguments: None
* Return value: None
**************************************************************/
void *wait_routine( void *para )
{
	t_timerinfo *p_tinfo = (t_timerinfo *)para;

	struct timespec interval = { 1, 0 };
	int max_num = p_tinfo->sec;

	for(int i=0; i<max_num; i++){

		if(*p_tinfo->p_kill_flag == true){
			break;
		}
		nanosleep( &interval, NULL );
	}

	return NULL;

}
/**************************************************************
* Function name: timer ()
* Description: Constructor
* Arguments: None
* Return value: None
**************************************************************/
timer::timer()
{
}
/**************************************************************
* Function name: wait_proc ()
* Description: Stop the specified time process (same effect as sleep)
*     If you pass kill_flag as argument to true, it will not take time
*     Wait for 0.01 second in 1 second plus time. Wait 5.05 seconds if you specify 5 seconds
* Argument: int sec: wait time
*     bool * p_kill_flag: wait abort flag
* Return value: None
**************************************************************/
void timer::wait_proc(int sec, const bool *p_kill_flag)
{
	pthread_t thread_id;

	t_timerinfo tinfo;
	tinfo.sec = sec;
	tinfo.p_kill_flag = p_kill_flag;
	pthread_create( &thread_id, NULL, wait_routine, &tinfo );
	pthread_join( thread_id, NULL );
	pthread_detach( thread_id );
	thread_id = 0;
	
}
