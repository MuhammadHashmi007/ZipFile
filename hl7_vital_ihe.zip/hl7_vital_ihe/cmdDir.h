
#include <vector>

#ifndef _CLASS_CMDDIR
#define _CLASS_CMDDIR


struct t_dirinfo {
	char full_path[128];	// the full path of the directory
	char lan_time[13];		// Directory name LAN time
};

class cmdDir
{
public:
	cmdDir(const char *p_dname_w, const char *p_dname_f);
	// Get effective directory list
	int getDirList(std::vector<t_dirinfo> *p_dirlist, int sort_sw);

	// Delete expired directory
	int deleteDirSaveDaysOver(int save_days, const char *p_dirname);

	// Get file list of specified directory
	int getFileList(const char *p_dname, std::vector<std::string> *p_flist);

private:
	bool checkDirName(const char *p_dname);
	void setDirInfo(const char *p_dname, t_dirinfo *p_info);
	void sortSetDirList(t_dirinfo *p_dinfo, std::vector<t_dirinfo> *p_dirlist, int sort_sw);
	void sortSetFileList(std::string *p_fname, std::vector<std::string> *p_flist);
	bool checkDirSaveDaysOver(const char *p_dname);
	void deleteDir(const char *p_dname, const char *p_dirname);
	int m_save_days;
	std::string m_xml_dir;
	std::string m_fail_dir;


};

#endif // _CLASS_CMDDIR
