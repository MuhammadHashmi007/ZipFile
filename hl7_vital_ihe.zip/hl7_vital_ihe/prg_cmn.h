

#ifndef _MAIN_HEADER
#define _MAIN_HEADER


#include <iostream>
#include <string>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/socket.h>  /* socket(), bind(), listen(), accept(). */
#include <netinet/in.h>
#include <arpa/inet.h>

#include <ibase.h>

// std's namespace
using namespace std;

#define ASCII_LF  0x0a
#define ASCII_CR  0x0d

#define CVWDB_USER "cvwuser"
#define CVWDB_PASSWD "cvwkanri"

// Program name etc.
#define MY_PROGRAM_NM "hl7_vital_ihe"
#define MY_PROGRAM_VER 103

// CVW server driver standard environment setting file name
#define CVW_SERVER_CONF "/usr/local/cvw/etc/cvwserver.conf"
#define CNF_PUBDB "CONNECT_DATABASE"

// hl7pam_adt configuration file
#define HL7PAM_CONF "/usr/local/cvw/etc/hl7vital_ihe.conf"
#define CNF_PORT "Listen_Port"
#define CNF_SOM "SOM_Charactor"
#define CNF_EOM "EOM_Charactor"
#define CNF_TIMEOUT "Socket_Timeout_Sec"
#define CNF_APP "Sending_Application"
#define CNF_FACT "Sending_Facility"
#define CNF_CODE "Country_Code"
#define CNF_CHAR "Character_Set"
#define CNF_LANG "Principal_Language"
#define CNF_PROF "Message_Profile_Identifier"
#define CNF_INVT "Invert_Name"
#define CNF_GDOMAIN "GlobalDomain"
#define CNF_LDOMAIN "LocalDomain"

// Save sequence number file
#define FILE_SEQUENCE "/usr/local/cvw/etc/hl7_vital_ihe_seq"

typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef unsigned char BYTE;

#endif // _MAIN_HEADER
