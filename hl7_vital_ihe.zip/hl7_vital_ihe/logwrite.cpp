
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <string>
#include <dirent.h>
#include <sys/stat.h>
#include "time.h"


#include "logwrite.h"

/**************************************************************
* Function name: logwrite ()
* Description: Constructor
* Arguments: None
* Return value: None
**************************************************************/
//logwrite::logwrite()
//{
//	logwrite( MY_PROGRAM_NM );
//}

logwrite::logwrite( const char *exe_name )
{
	sprintf( m_logpath_vital ,  "/usr/local/cvw/log/vital/%s.log",       exe_name);
	sprintf( m_logpath_time ,   "/usr/local/cvw/log/vital/%s_tm.log",    exe_name);
	sprintf( m_logpath_trace ,  "/usr/local/cvw/log/vital/%s_trace.log", exe_name);
	sprintf( m_logpath_pack ,   "/usr/local/cvw/log/vital/%s_pack.log",  exe_name);
}
/**************************************************************
* Function name: getfilesize ()
* Description: Get file size
* Arguments: const char *filename: File name
* Return value: None
**************************************************************/
long logwrite::getfilesize( const char *filename )
{
    struct stat filestat;
    
    int stat_err = stat( filename, &filestat );
    if( stat_err != -1 ) {
        return filestat.st_size;
    }
    return 0;
}

/**************************************************************
* Function name: findfile ()
* Explanation: Search log file
* Arguments: const char *filename: File name
* Return value: None
**************************************************************/
int logwrite::findfile( const char *findfilename )
{
    DIR *dirp;
    struct dirent *entp;
    dirp = opendir( LOG_DIR );
    std::string onefile;

    int ch = '/';
    char purefilenm[80];
    char *result;
    result = strrchr( (char *)findfilename, ch );
    if( result != NULL ) {
        strcpy( purefilenm, result + 1 );
    }
    else {
        strcpy( purefilenm, findfilename );
    }

    while(( entp = readdir( dirp )) != NULL ) {
        onefile = entp->d_name;
        if( 0 == onefile.compare( purefilenm )){
        	closedir( dirp );
        	 return 1;
        }
                                                    // Successful search
    }
    closedir( dirp );
    return 0;                                       // Serach failed
}

/**************************************************************
* Function name: moveLogFile ()
* Description: Rotation of logs
* Arguments: const char *filename: File name
*     int log_num: Number of files
* Return value: None
**************************************************************/
void logwrite::moveLogFile( const char *filename , int log_num)
{

    char objFilename[256];
    char srcFilename[256];
    char mkfilbuf[80];
    sprintf( mkfilbuf, ".%d", log_num - 1 );
    strcpy( objFilename, filename );
    strcat( objFilename, mkfilbuf );
    if( findfile( objFilename ) == 1 ) {
        // delete the maximum backup file if it exists
        remove( objFilename );
    }
    
    // Backup Move
    for( int i = log_num - 2; i > 0; i-- ) {
        sprintf( mkfilbuf, ".%d", i );
        strcpy( srcFilename, filename );
        strcat( srcFilename, mkfilbuf );
        if( findfile( srcFilename ) == 1 ) {
            sprintf( mkfilbuf, ".%d", i + 1 );
            strcpy( objFilename, filename );
            strcat( objFilename, mkfilbuf );
            rename( srcFilename, objFilename );
        }
    }
    strcpy( srcFilename, filename );
    strcpy( objFilename, filename );
    strcat( objFilename, ".1" );
    rename( srcFilename, objFilename );
}

/**************************************************************
* Function name: write_log ()
* Description: Write log
* Arguments: const char *log: String log to print/save
*    const char * filename: File name
*    int long_num: Number of files
*    const char * addr_str: String to be appened before log
* Return value: None
**************************************************************/
void logwrite::write_log( const char *log, const char *filename, int log_num, const char *add_str )
{

	char tmpbuf[80];
	time_t t;
	time( &t );
	strftime( tmpbuf, 80, "%Y%m%d %H%M%S ", localtime( &t ));

	FILE *fp;

	if( getfilesize(filename) >= LOG_MAX_FILESIZE ) {
		// log file move processing
		moveLogFile(filename, log_num );
	}

	fp = fopen( filename, "ab" );
	if( fp == NULL ) return;
	fputs( tmpbuf, fp );
	if( NULL != add_str){
		fputs( add_str, fp );
	}
	fputs( log, fp );
	fputs( "\r\n", fp );
	fclose( fp );
    return;
}

/**************************************************************
* Function name: job_log ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::job_log( const char *log )
{

	write_log( log, m_logpath_vital, LOG_MAX_VALUE, NULL );

    return;
}

/**************************************************************
* Function name: tm_log ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::tm_log( const char *log )
{

	write_log( log, m_logpath_time, LOG_MAX_VALUE, NULL );

    return;
}

/**************************************************************
* Function name: trace_log ()
* Description: Write log using default values
* Arguments: const char * func: Function Name
*    int line_no: Line number
*    const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::trace_log( const char *func, int line_no, const char *log )
{
	char line_char[8];
	sprintf( line_char , "%d", line_no);
	trace_str = func;
	trace_str += "():L";
	trace_str += line_char;
	trace_str += "::";
	trace_str += log;

	write_log( trace_str.c_str(), m_logpath_trace, LOG_TRACE_MAX_VALUE, NULL );

    return;
}
/**************************************************************
* Function name: connectlog ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::connectlog( const char *log )
{

	write_log( log, m_logpath_pack, LOG_MAX_VALUE, "[CONNECT] " );

    return;
}
/**************************************************************
* Function name: sendlog ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::sendlog( const char *log )
{

	write_log( log, m_logpath_pack, LOG_MAX_VALUE, "[SEND] "  );

    return;
}
/**************************************************************
* Function name: recvlog ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::recvlog( const char *log )
{

	write_log( log, m_logpath_pack, LOG_MAX_VALUE, "[RECV] "   );

    return;
}
/**************************************************************
* Function name: closelog ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::closelog( const char *log )
{

	write_log( log, m_logpath_pack, LOG_MAX_VALUE, "[CLOSE] "  );

    return;
}
/**************************************************************
* Function name: errlog ()
* Description: Write log using default values
* Arguments: const char * log: Sting to be print/save
* Return value: None
**************************************************************/
void logwrite::errlog( const char *log )
{

	write_log( log, m_logpath_pack, LOG_MAX_VALUE, NULL);

    return;
}
