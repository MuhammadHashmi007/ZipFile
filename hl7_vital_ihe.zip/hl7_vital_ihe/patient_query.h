
#ifndef _CLASS_PATIENT_QUERY
#define _CLASS_PATIENT_QUERY

#include "fb_base.h"

#define PATIENT_QUERY_FOUND		true
#define PATIENT_QUERY_NOTFOUND	false

class patient_query : public firebird_base
{
public:
	patient_query( string svnm );
	~patient_query();
	
	int find_patient( string pid );
	void get_patient_data( string pd );
	
	int patient_query_status;
	string patient_data;
	string patient_id;
	string patient_kana;
	string patient_name;
	string patient_bday;
	string patient_sex;
	string patient_pvn;
	string patient_apid;
	string patient_poc;
	string patient_pclass;
	string patient_room;
	string patient_bedid;
	string patient_facility;

private:
	string get_element( string str, char *sstr, char *estr );
	
	string database_str;
	
};

#endif // _CLASS_PATIENT_QUERY
