

#ifndef _CLASS_TIMER_
#define _CLASS_TIMER_

struct t_timerinfo {
	int         sec;          // wait time
	const bool *p_kill_flag;  // end flag
};

class timer
{
public:
	timer();
	void wait_proc(int sec, const bool *p_kill_flag);
private:

};

#endif // _CLASS_TIMER_
