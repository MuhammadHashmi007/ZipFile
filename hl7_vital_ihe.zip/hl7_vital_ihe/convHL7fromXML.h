
#include <vector>
#include "prg_cmn.h"
#include "confread.h"

#ifndef _CLASS_CONVHL7FROMXML
#define _CLASS_CONVHL7FROMXML
#define ID_FILE "/CVWDB/xml_vital/seq_id_save"

using namespace std;

// XML patient information structure
// Obtain information not to be used with HL7.
struct t_ptinfo {
	char ptid[32];           // patient ID
	char name[2][256];       // Name 0: Surname 1: Name 2: Second name
	char sex[2];             // Gender (HL 7 not used)
	char birth[11];          // Date of birth (HL 7 not used)
	char pvn[33];            // Patient Visit Number (ADT Integration)
	char apid[33];           // Alternative Patient ID (ADT Integration)
	char poc[33];            // Point of Care (ADT Integration)
	char pclass[3];          // Patient Class (ADT Integration)
	char room[65];           // Room/Location (ADT Integration)
	char bedid[65];          // Bed ID (Differ from Fukuda Bed ID) (ADT Integration)
	char facility[256];      // Facility (ADT Integration)
	char department_id[4];   // department ID (HL 7 not used)
	char department_nm[32];  // department name (HL 7 not used)
	char center_nm[32];      // center name (HL 7 not used)
	char bed_nm[16];         // floor number (HL 7 not used)
	char interval[5];        // interval (HL 7 not used)
	char data_time[17];      // data time
	char timezone_str[8];    // time zone value
};

struct t_measinfo {
	char prm_code[256];         // parameter code
	char value[8];              // measured value data
	char unit_id[4];
	char unit_nm[256];          // unit
	char label[8];              // label
	char meas_time[17];         // measurement date and time
	char meas_timezone_str[8];  // time zone value
	char count[4];              // counter for discontinuous parameters
};

#include "patient_query.h"

class convHL7fromXML
{

public:
	convHL7fromXML(confread *p_confrdt, patient_query *pdb, const char *exe_name );
	string convHL7(string xml, unsigned long seq, int msgidnum, vector<t_prminfo> *p_prmlist, vector<t_untinfo> *p_untlist);

private:
	
	string m_som;
	string m_eom;
	string m_rcvappli;

	confread *mp_confrdt;
	patient_query *mp_pq;
	
	string m_timezone_str_dst0;
	string m_timezone_str_dst1;
	void getPtInfo(string xml,   t_ptinfo *p_ptinfo);
	void getMeasInfo(string xml, vector<t_measinfo> *p_measlist, vector<t_prminfo> *p_prmlist, vector<t_untinfo> *p_untlist);

	void getTagData(string xml,  string tagstr, char *p_data, string::size_type datasize);
	void getTagData(string xml,  string tagstr, string *p_data);
	void setName(t_ptinfo *p_ptinfo, string name);
	void getTagDataMeas(t_measinfo *p_meas, string xml, string tagstr, vector<t_untinfo> *p_untlist, vector<t_prminfo> *p_prmlist);

	bool checkTag(string tagstr, vector<t_prminfo> *p_prmlist);
	void setPrmCount(t_measinfo *p_meas, vector<t_measinfo> *p_measlist);
	void convTimeStr(string &timestr);
	void getTimeZoneStr(char *p_timezone, string xml);
	void getDataTimeStr(char *p_time, string xml);
	bool checkUnitId(string untstr, vector<t_untinfo> *p_untlist);
	void getUnitName(char *p_untidstr, char *p_data,  vector<t_untinfo> *p_untlist);
	void getParamCode(string prmtagstr, char *p_data, vector<t_prminfo> *p_prmlist);
	void replaceSpecialChar(string *p_data, string str);

	char m_exe_name[64];

};

#endif // _CLASS_CONVHL7FROMXML
