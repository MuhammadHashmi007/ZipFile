
#include <stdio.h>
#include <sys/stat.h>  // stat()
#include <string>
#include <vector>
#include <dirent.h>

#ifndef _PATH_RELATE
// function extern declaration
extern void path_add_slash( char* path );
extern void path_remove_extension( char* path );
extern bool path_add_extension(  char* path, const char* ext );
extern bool path_rename_extension( char* path, const char* ext );
extern char* path_combine( char* dest, const char* dir, const char* file );
extern bool path_remove_file_spec( char* path );
extern bool path_is_directory( const char* path );
extern bool path_file_exists( const char* path );
extern char* path_find_extension( const char* path );
extern bool make_directory_path_exists( const char* path );
extern char* path_find_filename( const char* path );
extern std::vector<std::string> find_first_file( const char* dir );
extern int file_copy( const char* src ,const char* obj );



#else
// Actual state
void path_add_slash( char* path );
void path_remove_extension( char* path );
bool path_add_extension(  char* path, const char* ext );
bool path_rename_extension( char* path, const char* ext );
char* path_combine( char* dest, const char* dir, const char* file );
bool path_remove_file_spec( char* path );
bool path_is_directory( const char* path );
bool path_file_exists( const char* path );
char* path_find_extension( const char* path );
bool make_directory_path_exists( const char* path );
char* path_find_filename( const char* path );
std::vector<std::string> find_first_file( const char* dir );
int file_copy( const char* src ,const char* obj );

/* Add '/' at end of path */
void path_add_slash( char* path )
{
	if( path[strlen( path ) - 1] != '/' ) {
		strcat( path, "/" );
	}
}

/* Deletes the extension (it searches from the end of the string and just sets the first '.' To NULL) */
void path_remove_extension( char* path )
{
	int i;
	for( i = strlen( path ) - 1; i != 0; i-- ) {
		if( path[i] == '.' ) {
			path[i] = 0x00;
			break;
		}
		else if( path[i] == '/' ) {
			break;
		}
	}
}

/* Add extension to path name (Return 'error true' if it already has '.') */
bool path_add_extension( char* path, const char* ext )
{
	int path_len = strlen( path );
	if( path[path_len - 1] == '/' ) return true;
	int i;
	if( path[path_len - 1] != '.' ) {
		// If the final character is other than '.', And '/' precedes '.' An error
		for( i = path_len - 1; i != 0; i-- ) {
			if( path[i] == '.' ) {
				return true;
			}
			else if( path[i] == '/' ) {
				break;
			}
		}
	}
	
	int ext_len = strlen( ext );
	if( ext_len == 0 ) return true;
	if( ext[0] != '.' ) {
		strcat( path, "." );
	}
	path_len = strlen( path );
	if( path_len + ext_len > PATH_MAX ) return true;
	strcat( path, ext );
	return false;
}

/* Change path extension */
bool path_rename_extension( char* path, const char* ext )
{
	path_remove_extension( path );
	return path_add_extension( path, ext );
}

/* Join of directory name and file name (return value is dest pointer, failure is NULL) */
/* There is a failure in the original Windows API, but with the simplified version �, almost no failure */
char* path_combine( char* dest, const char* dir, const char* file )
{
	char* ret_point = dest;
	
	int dir_len = strlen( dir );
	if( dir_len == 0 ) return NULL;
	strcpy( dest, dir );
	path_add_slash( dest );
	
	int file_len = strlen( file );
	if( file_len == 0 ) return NULL;
	if( file[0] != '/' ) {
		strcat( dest, file );
	}
	else {
		strcat( dest, &file[1] );
	}
	
	return ret_point;
}

/* Remove filename part from path */
/* Search from the end of the path and make the first \ NULL */
bool path_remove_file_spec( char* path )
{
	int i;
	for( i = strlen( path ) - 1; i != 0; i-- ) {
		if( path[i] == '/' ) {
			path[i] = 0x00;
			break;
		}
	}
	if( i == 0 ) return true;
	return false;
}

/* Determine whether the specified directory exists */
/* true exists false does not exist */
bool path_is_directory( const char* path )
{
	struct stat dir_sts;
	if( stat( path, &dir_sts ) != 0 ) {
		return false;
	}
	return true;
}

/* Determine if file exists */
/* true exists false does not exist */
bool path_file_exists( const char* path )
{
	// Since it is the same as the existence confirmation of the directory ...
	return path_is_directory( path );
}

/* Obtain extension from file path */
char* path_find_extension( const char* path )
{
	int i;
	for( i = strlen( path ) - 1; i != 0; i-- ) {
		if( path[i] == '.' ) {
			i = i + 1;
			break;
		}
		else if( path[i] == '/' ) {
			return NULL;
		}
	}
	return (char*)(path + i);
}


/* Create new directory */
/* path is a string ending in /. If it does not end with /, it regards the end as a file name */
/* / aaa / bbb / ccc -> It is created in / aaa / bbb */
/* Return value true: Creation failed false: Success */
bool make_directory_path_exists( const char* path )
{
	umask( 0 );
	char buf[PATH_MAX];
	long pos = 0;
	long path_len = strlen( path );
	long l, m;
	for( l = 0; l < path_len; l++ ) {
		if( path[pos] != '/' ) return true;
		for( m = l + 1; m < path_len; m++ ) {
			if( path[m] == '/' ) {
				pos = m;
				break;
			}
		}
		if( m >= path_len ) return false;
		memcpy( buf, path, m );
		buf[m] = 0x00;
		if( !path_file_exists( buf )) {
			if( mkdir( buf, ACCESSPERMS ) != 0 ) {
				return true;
			}
		}
		l = m;
	}
	return false;
}

/* Get file name part from file path */
char* path_find_filename( const char* path )
{
	int i;
	for( i = strlen( path ) - 1; i != 0; i-- ) {
		if( path[i] == '/' ) {
			i = i + 1;
			break;
		}
	}
	if( i == 0 ) return NULL;
	return (char*)(path + i);
}


// Return file list of specified directory
// Patterns that return both directory and file
std::vector<std::string> find_first_file( const char* dir )
{
	std::vector<std::string> fl;
//  directories such as mount.cifs seem to be nonexistent by path_is_directory ()
//	if( !path_is_directory( dir )) return fl;
	
	DIR* dirp;
	struct dirent* entp;
	dirp = opendir( dir );
	if( NULL == dirp )  return fl;
	while(( entp = readdir( dirp )) != NULL ) {
		if( 0 == strcmp( entp->d_name, "." )) continue;
		if( 0 == strcmp( entp->d_name, ".." )) continue;
		fl.push_back( std::string( entp->d_name ));
	}
	closedir( dirp );
	return fl;
}

// Copy files
// Read 1 byte and write 1 byte.
// It's a bit slow, so it's not suitable for large file copies.
int file_copy( const char* src ,const char* obj )
{
	FILE* fp_s = fopen( src ,"rb" );
	if( fp_s == NULL ) return 1;
	FILE* fp_o = fopen( obj ,"wb" );
	if( fp_o == NULL ) {
		fclose( fp_s );
		return 1;
	}
	char c;
	while( true ) {
		fread( &c ,sizeof(c) ,1 ,fp_s );
		if( feof( fp_s )) break;
		fwrite( &c ,sizeof(c) ,1 ,fp_o );
	}
	fclose( fp_s );
	fclose( fp_o );
	return 0;
}

#endif // _PATH_RELATE
