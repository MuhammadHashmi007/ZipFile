#include <iostream>
#include <climits>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/times.h> 
#include <dirent.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include <unistd.h> 
#include <fcntl.h>

#include "prg_cmn.h"
#include "sckProc.h"
#include "logwrite.h"
#include "cmdDir.h"
#include "convHL7fromXML.h"

#define POS_MSG_TYPE    8
#define POS_RES_CODE    1
#define POS_MSG_ID_SEND 9
#define POS_MSG_ID_RECV 2

#define STR_MSG_TYPE "ACK^R01"
#define STR_RES_CODE_AA "AA"
#define STR_RES_CODE_CA "CA"

/**************************************************************
* Function name: sckProc ()
* Description: Constructor
* Arguments: None
* Return value: None
**************************************************************/
sckProc::sckProc( confread  *p_confrdt, const char *exe_name )
{
	m_p_confrdt = p_confrdt;
	strcpy( m_exe_name, exe_name );
	
	// Read parameter setting file
	m_p_confrdt->getPrmList(&m_prmlist);

	// Read unit setting file
	m_p_confrdt->getUntList(&m_untlist);

	// Read message control ID serial number and sequence number
	getSeqId(&m_msgidnum, &m_HL7seq);
	
	// Set server date and time
	memset(m_server_date, 0, sizeof(m_server_date));
	time_t t;
	time( &t );
	strftime( m_server_date, sizeof(m_server_date), "%Y%m%d", localtime( &t ));

}
/**************************************************************
* Function name: sendProc ()
* Description: Transmission reception processing
* Argument: t_dirinfo * p_dinfo: transmission directory information
* Return value: int 0: Success 1: Error
**************************************************************/
int sckProc::sendProc(const t_dirinfo *p_dinfo)
{
	struct  tms dumy;
	clock_t startclock;
	clock_t endclock;
	startclock = times( &dumy );
	logwrite logdat( m_exe_name ) ;
	char logbuf[256];

	// ----------------------------------------  Get transmission file list ---
	cmdDir cdir(m_p_confrdt->m_workdir.c_str(), m_p_confrdt->m_faildir.c_str());
	std::vector<std::string> flist;
	int filenum = cdir.getFileList(p_dinfo->full_path, &flist);
	sprintf(logbuf, "DIRECTORY PATH:%s  FILE NUM:%d", p_dinfo->full_path, filenum);
	logdat.trace_log( __func__, __LINE__, logbuf );

	// If the file is 0 delete the directory and exit
	if(filenum == 0){
		if(rmdir(p_dinfo->full_path) < 0){
			char cmdchar[128];
			sprintf(cmdchar, "rm -rf %s", p_dinfo->full_path);
			system(cmdchar);
		}
		sprintf(logbuf, "REMOVE DIRECTORY:%s", p_dinfo->full_path);
		logdat.trace_log( __func__, __LINE__, logbuf );
		return 0;
	}
	// --------------------------------------------------------------------
	// Connection
	// --------------------------------------------------------------------
	if(m_sck.sck_connect((char *)m_p_confrdt->m_destination_host.c_str(), m_p_confrdt->m_destination_port) < 0){
		endclock = times( &dumy );
		float subclock = endclock - startclock;
		subclock = subclock / 100;
		memset(logbuf, 0, 256);
		sprintf(logbuf, "L:%s !!ERR CONNECT!!  %.2f SEC", p_dinfo->lan_time,  subclock);
		logdat.tm_log(logbuf);
		logdat.job_log(logbuf);
		sprintf(logbuf, "!!ERR CONNECT!!  L:%s",  p_dinfo->lan_time);
		logdat.connectlog(logbuf);
		return -1;
	}

	sprintf(logbuf, "IP:%s PORT:%d", (char *)m_p_confrdt->m_destination_host.c_str(),  m_p_confrdt->m_destination_port);
	logdat.connectlog( logbuf );
	sprintf(logbuf, "CONNECT %s", p_dinfo->full_path);
	logdat.job_log(logbuf);
	
	// --------------------------------------------------------------------
	// DB connection
	// --------------------------------------------------------------------
	patient_query *pdb = NULL;
	if( m_p_confrdt->m_ds_adt_mode.compare("1") == 0 ){
		pdb = new patient_query( m_p_confrdt->m_pub_database );
	}
		
	// ----------------------------------------------------------------------------------
	// Declare HL 7 Convert Class
	// Set the necessary SOM, EOM and receiving application with HL7 message in the constructor
	// ----------------------------------------------------------------------------------
	convHL7fromXML cvhl7( m_p_confrdt, pdb, m_exe_name );

	// --------------------------------------------------------------------
	// Repeat processing as many as the number of files
	// --------------------------------------------------------------------
	int oknum=0;
	int errnum=0;
	std::vector<std::string>::iterator file_pos;
	for( file_pos = flist.begin(); file_pos != flist.end(); file_pos++ ) {
		// ----------------------------------------- Get XML data from file ---
		std::string xmldata = "";
		if(getXmlData( (*file_pos).c_str(), &xmldata ) < 0){
			m_sck.sck_close();
			delete pdb;
			return -1;
		}

		// Check date and time
		char today[16];
		memset(today, 0, sizeof(today));
		time_t t;
		time( &t );
		strftime( today, sizeof(today), "%Y%m%d", localtime( &t ));
		if(strcmp(today, m_server_date) != 0){
			m_msgidnum = 0;
			strcpy(m_server_date, today);
			sprintf(logbuf, "SERVER TIME RESET: %s", m_server_date);
			logdat.trace_log( __func__, __LINE__, logbuf );
		}
		m_msgidnum++;
		
		// ------------------------------------- Conversion from XML to HL7 ---
		std::string hl7data = cvhl7.convHL7(xmldata, m_HL7seq, m_msgidnum,  &m_prmlist, &m_untlist);

		// -------------------------------- Sending and receiving Processing ---
		int ret = onePatiProc((*file_pos).c_str(), &hl7data);

		switch(ret){
		case RECV_OK:
			oknum++;
			// File delete
			if(remove((*file_pos).c_str()) < 0){
				sprintf(logbuf, "!!ERR FILE REMOVE!! %s", (*file_pos).c_str());
				logdat.trace_log( __func__, __LINE__, logbuf );
			}
			break;
		case RECV_ERR_DATA:
			errnum++;
			moveFileFailDir(p_dinfo->full_path, (*file_pos).c_str());
			break;
		case RECV_ERR_SOCKET:
			errnum++;
			if( m_p_confrdt->m_fail_by_socket_err == "true" ){
				// Move record to fail directory
				errnum++;
				moveFileFailDir(p_dinfo->full_path, (*file_pos).c_str());
			}
			//return -1;
			break;
		}

		// message control ID, sequence number check
		if(m_HL7seq == ULONG_MAX){
			m_HL7seq = 0;
		}
		m_HL7seq++;
		
		// hold message control ID
		std::string writebuf;
		char intstr[16];
		writebuf += m_server_date;
		sprintf(intstr, "%06d", m_msgidnum);
		writebuf += intstr;
		writebuf += "\r";
		sprintf(intstr, "%ld", m_HL7seq);
		writebuf += intstr;
		FILE *fp;
		fp = fopen( ID_FILE, "w" );
		if( fp != NULL ){
			fputs( writebuf.c_str(), fp );
			fclose( fp );
		}
	}
	// --------------------------------------------------------------------
	// Cut
	// --------------------------------------------------------------------
	m_sck.sck_close();
	logdat.closelog("");

	if( m_p_confrdt->m_ds_adt_mode.compare("1") == 0 ){
		delete pdb;
	}
	// --------------------------------------------------------------------
	// Delete directory
	// --------------------------------------------------------------------
	filenum = cdir.getFileList(p_dinfo->full_path, &flist);
	if(filenum == 0){
		if(rmdir(p_dinfo->full_path) < 0){
			char cmdchar[128];
			sprintf(cmdchar, "rm -rf %s", p_dinfo->full_path);
			system(cmdchar);
		}
	}
	endclock = times( &dumy );
	float subclock = endclock - startclock;
	subclock = subclock / 100;
	sprintf(logbuf, "L:%s OK:%3d NG:%3d   %.2f SEC", 
					p_dinfo->lan_time, 
					oknum,
					errnum,
					subclock);
	logdat.tm_log(logbuf);

	return 0;
}
/**************************************************************
* Function name: getXmlData ()
* Description: Acquire transmission data from file
* Arguments: char * p_fname: File
*     std::string * p_sdata: transmission data
* Return value: int 0: success -1: error
**************************************************************/
int sckProc::getXmlData(const char *p_fname, std::string *p_sdata)
{
	int filesize = getfilesize(p_fname);
	if(filesize == 0){
		return -1;
	}
	char *readbuf = new char[filesize+1];

	int fd;
	fd = open( p_fname, O_RDONLY | O_SYNC | O_RDONLY );
	if( fd < 0 ) {
		delete[] readbuf;
		return -1;
	}
	
	int readret = read( fd, (void *)readbuf, filesize );
	if( readret < 0 ) {
		delete[] readbuf;
		close( fd );
		return -1;
	}
	close( fd );
	readbuf[filesize] = 0;
	*p_sdata = readbuf;
	delete[] readbuf;

	return 0;
}
/**************************************************************
* Function name: getfilesize ()
* Description: Get file size
* Arguments: char * p_fname: File
* Return value: long file size
**************************************************************/
long sckProc::getfilesize(const char *p_fname)
{
	struct stat filestat;
	
	int stat_err = stat( p_fname, &filestat );
	if( stat_err != -1 ) {
		return filestat.st_size;
	}
	return 0;
}
/**************************************************************
* Function name: onePatiProc ()
* Description: One patient's treatment
* Argument: const char * p_fname: transmission message file name (used for log output)
*     std::string * p_sdata: transmission message
* Return value: int 0: Normal minus: Error code
**************************************************************/
int sckProc::onePatiProc(const char *p_fname, std::string *p_sdata)
{
	logwrite logdat( m_exe_name );
	char logbuf[256];

	// ---------------------------------------------------------
	// send
	// ---------------------------------------------------------
	if(m_sck.sck_send( (void *)p_sdata->c_str(), p_sdata->size()) < 0){
		logdat.job_log("!!ERR SEND!! SOCKET ERR");
		return RECV_ERR_SOCKET;
	}
	logdat.sendlog((char *)p_sdata->c_str());

	// ---------------------------------------------------------
	// receive
	// ---------------------------------------------------------
	std::string recvstr = "";
	if(m_sck.sck_recv_eom( m_p_confrdt->m_socket_timeout_sec, &recvstr, m_p_confrdt->m_eom_char.c_str()) < 0){
		logdat.recvlog((char *)m_sck.GetErrMessage().c_str());
		sprintf(logbuf, "%s %s ", p_fname, (char *)m_sck.GetErrMessage().c_str());
		logdat.job_log(logbuf);
		return RECV_ERR_SOCKET;
	}
	logdat.recvlog((char *)recvstr.c_str());

	// ---------------------------------------------------------
	// Check received message
	// ---------------------------------------------------------
	if( checkRecvPack(p_sdata, &recvstr, p_fname)  < 0 ){
		return RECV_ERR_DATA;
	}

	return RECV_OK;
}
/**************************************************************
* Function name: moveFileFailDir ()
* Description: Move the file to the fail directory
* Arguments: const char * p_dname: The directory where the file before the move was located
*     const char * p_fname: file (full path)
* Return value: None
**************************************************************/
void sckProc::moveFileFailDir(const char *p_dname, const char *p_fname)
{
	logwrite logdat( m_exe_name );
	char logbuf[256];
	// Create directory of transmission LAN time under CVWDB/vital/fail
	// The directory name is created by changing the work directory to fail.
	std::string dirname = p_dname;

	// Change the position of the "work" character string became variable
	// dirname.replace (17, 4, "fail");
	long work_pos = dirname.find("work", 0);
	dirname.replace(work_pos, 4, "fail");

	struct stat dst;
	if( stat(dirname.c_str(), &dst) < 0 ){
		if(mkdir( dirname.c_str(), ACCESSPERMS ) != 0){
			sprintf(logbuf, "!!CREATE DIRECTORY ERR!! %s", dirname.c_str());
			logdat.trace_log( __func__, __LINE__, logbuf );
		}

		sprintf(logbuf, "mkdir %s ", dirname.c_str() );
		logdat.job_log(logbuf);
	}

	std::string newfname = p_fname;
	//newfname.replace(17, 4, "fail");
	newfname.replace(work_pos, 4, "fail"); // Since v102 changed the position of "work" string, it changed
	if(rename(p_fname, newfname.c_str()) != 0 ){
		//std::cout << errno << ":" << strerror(errno) << std::endl;
		sprintf(logbuf, "!!ERR!! %s, %s", p_fname, newfname.c_str());
		logdat.trace_log( __func__, __LINE__, logbuf );
	}

	sprintf(logbuf, "rename %s -> %s  ", p_fname, newfname.c_str() );
	logdat.job_log(logbuf);
}

/**************************************************************
* Function name: checkRecvPack ()
* Description: Check received message
* Argument: std :: string * p_sendstr: transmission message
*     std::string * p_recvstr: received message
*     const char * p_fname: xml file name
* Return value: int 0: OK -1: Error
**************************************************************/
int sckProc::checkRecvPack(std::string *p_sendstr, std::string *p_recvstr, const char *p_fname)
{
	logwrite logdat( m_exe_name );
	char logbuf[256];

	std::string segMSHstr = "";
	get1Segment(&segMSHstr, p_recvstr, "MSH");
	std::string segMSAstr = "";
	get1Segment(&segMSAstr, p_recvstr, "MSA");

	// Get the elements of the received message
	std::string msgtype = "";
	std::string rescode = "";
	std::string msgidstr_recv = "";
	get1data(&msgtype, &segMSHstr, POS_MSG_TYPE);			// message type
	get1data(&rescode, &segMSAstr, POS_RES_CODE);			// response code
	get1data(&msgidstr_recv, &segMSAstr, POS_MSG_ID_RECV);	// message control ID


	// Get the element of the transmitted message
	std::string segMSHstr_send = "";
	get1Segment(&segMSHstr_send, p_sendstr, "MSH");
	std::string msgidstr_send = "";
	get1data(&msgidstr_send, &segMSHstr_send, POS_MSG_ID_SEND);	// message control ID

	std::string msgtype_str = STR_MSG_TYPE;
	int result = msgtype.compare(0, 7, msgtype_str);
	
	// response code: AA or CA, message type: ACK ^ R 01, message control ID match
	// CA permission added with v 102
	// if(!(rescode == STR_RES_CODE_AA && result == 0 && msgidstr_send == msgidstr_recv)){
	int res = true;
	res &= (rescode == STR_RES_CODE_AA || rescode == STR_RES_CODE_CA);
	if( "true" != m_p_confrdt->m_ack_ignore_message_type){			// Ignore Message Type in ACK?
		res &= ( result == 0 );
	}
	res &= (msgidstr_send == msgidstr_recv);
	
	if( res != true ) {
		sprintf(logbuf, "!!RESPONSE ERR!!%s (rescode=%s, result=%d, msgid send/recv=%s/%s)", p_fname, rescode.c_str(), result, msgidstr_send.c_str(), msgidstr_recv.c_str());
		logdat.job_log(logbuf);
		sprintf(logbuf, "       [%s, %s]", msgtype.c_str(), rescode.c_str());
		logdat.job_log(logbuf);
		sprintf(logbuf, "       [SEND:%s, RECV:%s]", msgidstr_send.c_str(), msgidstr_recv.c_str());
		logdat.job_log(logbuf);
		return -1;
	}
	sprintf(logbuf, "%s:OK [%s, %s] ", p_fname, msgtype.c_str(), rescode.c_str());
	logdat.job_log(logbuf);

	return 0;
}
/**************************************************************
* Function name: get1Segment ()
* Description: Extract one segment of telegram from HL7 telegram
* Argument: std :: string * p - 1 seg: 1 segment
*     std::string * p_hl 7: HL 7 message
*     std::string * p_key: Segment key (such as MSH)
* Return value: None
**************************************************************/
void sckProc::get1Segment(std::string *p_1seg, std::string *p_hl7, const char *p_key)
{
	string::size_type pos1, pos2;
	pos1 = p_hl7->find(p_key, 0);

	int keysize = strlen(p_key);
	if(pos1 != string::npos){
		pos2 = p_hl7->find("\r", pos1);
		if(pos1 != string::npos){
			*p_1seg = p_hl7->substr(pos1+keysize, pos2 - pos1 - keysize);
		}
	}
}
/**************************************************************
* Function name: get1data ()
* Description: Extract one data of one segment.
* Argument: std :: string * p_data: extracted data
*     std::string * p_1_seg: 1 segment
*     int pos: position of data
* Return value: None
**************************************************************/
void sckProc::get1data(std::string *p_data, std::string *p_1seg, int pos)
{

	string::size_type pos1 = 0, posbk = 0;
	int pos_cnt = 0;

	bool nposflag = false;

	while(true){
		pos1 = p_1seg->find("|", pos1);
		if(pos1 == std::string::npos){
			nposflag = true;
			break;
		}

		if(pos == pos_cnt){
			break;
		}
		pos_cnt++;
		posbk = pos1;
		pos1 = pos1 + 1;
	}

	if(nposflag == false){
		*p_data = p_1seg->substr(posbk+strlen("|"), pos1 - posbk - strlen("|"));
	}else if(nposflag == true && pos_cnt == pos){
		*p_data = p_1seg->substr(posbk+strlen("|"));
	}

}
/**************************************************************
* Function name: getSeqId ()
* Description: Obtain serial number and sequence number of message control ID
* Argument: int * p_dataid: The acquired serial number
*     unsigned long * p_dataseq: Number acquired
* Return value: None
**************************************************************/
void sckProc::getSeqId(int *p_dataid, unsigned long *p_dataseq)
{
	// Read message control ID serial number and sequence number
	FILE *fp;
	fp = fopen( ID_FILE, "r" );
	if( fp == NULL ) {
		*p_dataid = 0;
		*p_dataseq = 1;
		return;
	}
	char readbuf[32];
	char idstr[10];
	if( fgets(readbuf, 32, fp) == NULL ) {
		*p_dataid = 0;
		*p_dataseq = 1;
		fclose( fp );
		return;
	}
	fclose( fp );
	memcpy(idstr, &readbuf[8], 6);
	*p_dataid = atoi(idstr);
	
	memset(idstr, 0, sizeof(idstr));
	
	memcpy(idstr, &readbuf[15], 10);
	unsigned long idnum = strtoul(idstr, NULL, 0);
	if(idnum != ULONG_MAX){
		*p_dataseq = strtoul(idstr, NULL, 0) + 1;
	} else {
		*p_dataseq = 1;
	}
}

