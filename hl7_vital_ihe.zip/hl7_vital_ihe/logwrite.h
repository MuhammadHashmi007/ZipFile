
#ifndef _CLASS_LOGWRITE
#define _CLASS_LOGWRITE

// Maximum number of log files
#define LOG_MAX_VALUE 4
#define LOG_TRACE_MAX_VALUE 4
// Maximum log file size (4 Meg)
#define LOG_MAX_FILESIZE (1024*1024*4)
#define LOG_DIR           "/usr/local/cvw/log/vital"
#define FNAME_VITAL_LOG   "/usr/local/cvw/log/vital/hl7_vital_ihe.log"
#define FNAME_TIME_LOG    "/usr/local/cvw/log/vital/hl7_vital_ihe_tm.log"
#define FNAME_TRACE_LOG   "/usr/local/cvw/log/vital/hl7_vital_ihe_trace.log"
#define FNAME_PACK_LOG    "/usr/local/cvw/log/vital/hl7_vital_ihe_pack.log"

class logwrite
{
public:
//    logwrite();
    logwrite( const char *exe_name );

	void job_log   ( const char *log );
	void tm_log    ( const char *log );
	void trace_log ( const char *func, int line_no, const char *log );
	void connectlog( const char *log );
	void sendlog   ( const char *log );
	void recvlog   ( const char *log );
	void closelog  ( const char *log );
	void errlog    ( const char *log );
	char m_logbuf[256];

private:
	void write_log  ( const char *log, const char *filename, int log_num,  const char *add_str );
	long getfilesize( const char *filename );
	int  findfile   ( const char *findfilename );
	void moveLogFile( const char *filename, int log_num );
	std::string trace_str;
    
	char m_logpath_vital[256];
	char m_logpath_time[256];
	char m_logpath_trace[256];
	char m_logpath_pack[256];
};


#endif // _CLASS_LOGWRITE
