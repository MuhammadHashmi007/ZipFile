
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "confread.h"
#include "logwrite.h"
using namespace std;

// OBX Segment
static char* prmTbl[] = {
	"HR",
	"ST1",
	"ST2",
	"VPC_M",
	"VPC_H",
	"SPO2",
	"PR",
	"Tsk",
	"Tre",
	"Tes",
	"Tco",
	"T1",
	"T2",
	"T3",
	"T4",
	"T5",
	"T6",
	"T7",
	"T8",
	"RR",
	"APNEA",
	"ETCO2",
	"INSPCO2",
	"NBP_S",
	"NBP_D",
	"NBP_M",
	"BP1_S",
	"BP1_D",
	"BP1_M",
	"BP2_S",
	"BP2_D",
	"BP2_M",
	"BP3_S",
	"BP3_D",
	"BP3_M",
	"BP4_S",
	"BP4_D",
	"BP4_M",
	"BP5_S",
	"BP5_D",
	"BP5_M",
	"BP6_S",
	"BP6_D",
	"BP6_M",
	"BP7_S",
	"BP7_D",
	"BP7_M",
	"BP8_S",
	"BP8_D",
	"BP8_M",
	"ART_S",
	"ART_D",
	"ART_M",
	"RAP_S",
	"RAP_D",
	"RAP_M",
	"RVP_S",
	"RVP_D",
	"RVP_M",
	"PAP_S",
	"PAP_D",
	"PAP_M",
	"CVP_M",
	"ICP_S",
	"ICP_D",
	"ICP_M",
	"UAP_S",
	"UAP_D",
	"UAP_M",
	"IAP_S",
	"IAP_D",
	"IAP_M",
	"LAP_S",
	"LAP_D",
	"LAP_M",
	"LVP_S",
	"LVP_D",
	"LVP_M",
	"PCWP",
	"TV_I",
	"TV_E",
	"MV",
	"PEAK",
	"PEEP",
	"SVO2",
	"CCO",
	"CCI",
	"BT",
	"TCPO2",
	"TCPCO2",
	"CO2_I",
	"CO2_E",
	"O2_I",
	"O2_E",
	"N2O_I",
	"N2O_E",
	"ISO_I",
	"ISO_E",
	"HAL_I",
	"HAL_E",
	"ENF_I",
	"ENF_E",
	"SEV_I",
	"SEV_E",
	"DES_I",
	"DES_E",
	"AGT_I",
	"AGT_E",
	"AGT2_I",
	"AGT2_E",
	"MAC",
	"ST_I",
	"ST_II",
	"ST_III",
	"ST_aVR",
	"ST_aVL",
	"ST_aVF",
	"ST_V1",
	"ST_V2",
	"ST_V3",
	"ST_V4",
	"ST_V5",
	"ST_V6",
	"BIS",
	"BIS_SQI",
	"BIS_EMG",
	"BIS_SR",
	"SCVO2",
	"Rt_rSO2",
	"Lt_rSO2",
	"S1_rSO2",
	"S2_rSO2",
	"SPCO",
	"SPMET",
	"PI",
	"PVI",
	"MV_E_SPIRO",
	"PEAK_SPIRO",
	"PEEP_SPIRO",
	"TV_I_SPIRO",
	"TV_E_SPIRO",
	"SPO2_2",
	"PR_2",
	"SPCO_2",
	"SPMET_2",
	"PI_2",
	"PVI_2",
	"SPHB",
	"SPHB_2",
	"PR_IBP",
	"CPP",
	"PDP",
	"Tb",
};
#define PRM_TBL_NUM sizeof(prmTbl)/sizeof(char*)

static char* untTbl[] = {
	"Unit01",
	"Unit02",
	"Unit03",
	"Unit04",
	"Unit05",
	"Unit06",
	"Unit07",
	"Unit08",
	"Unit09",
	"Unit10",
	"Unit11",
	"Unit12",
	"Unit13",
	"Unit14",
	"Unit15",
	"Unit16",
	"Unit17",
	"Unit18",
	"Unit19",
	"Unit20",
	"Unit21",
	"Unit22",
	"Unit23",
	"Unit24",
	"Unit25",
	"Unit26",
	"Unit27",
	"Unit28",
	"Unit29",
};
#define UNT_TBL_NUM sizeof(untTbl)/sizeof(char*)

/**************************************************************
* Function name: confread ()
* Description: Constructor
* Arguments: None
* Return value: None
**************************************************************/
confread::confread( const char *exe_name )
{
	// �����
	sprintf(m_conf_path, "/usr/local/cvw/etc/%s.conf", exe_name);
	m_data_sort = 0;
	
	m_destination_port = 0;
	m_socket_timeout_sec = 0;
	m_storing_days = 0;
	m_send_wait_sec = 5;

	strcpy( m_exe_name, exe_name );

}
/**************************************************************
* Function name: vitalConf ()
* Description: hl7_vital_gw.conf load
* Arguments: None
* Return value: None
**************************************************************/
void confread::vitalConf()
{
	logwrite logdat( m_exe_name );
	logdat.trace_log( __func__, __LINE__, m_conf_path );

	int filesize = getfilesize(m_conf_path);
	char *readbuf = new char[filesize];

	int fd;
	fd = open( m_conf_path, O_RDONLY | O_SYNC | O_RDONLY );
	//cout << errno << ":" << strerror(errno) << endl;
	if( fd < 0 ) {
		delete[] readbuf;
		return;
	}
	
	int readret = read( fd, (void *)readbuf, filesize );
	if( readret < 0 ) {
		delete[] readbuf;
		close( fd );
		return;
	}
	close( fd );

	string valuestr;
	for( int i = 0; i < filesize; i++ ) {
		if( readbuf[i] == 0x0a || readbuf[i] == 0x0d ) {
			readbuf[i] = 0x0d;
		}
		if( readbuf[i] == '#' ) {
			while( i < filesize ) {
				i++;
				if( readbuf[i] == 0x0a || readbuf[i] == 0x0d ) break;
			}
			continue;
		}
		valuestr.append( 1, readbuf[i] );
	}
	delete[] readbuf;
	logdat.trace_log( __func__, __LINE__, "LOAD CONF FILE" );

	//---------- [Common] ----------
	m_pub_database = getValueString( valuestr, CNF_PUBDB );
	m_pub_database = m_pub_database.append( ":/CVWDB/cvwpub.fdb" );
	m_ds_adt_mode = getValueString( valuestr, CNF_MODE );
	m_destination_host	= getValueString( valuestr, DEST_HOST);			// Destination_Host
	m_destination_port	= getValuePoint( valuestr, DEST_PORT);			// Destination_Port
	m_socket_timeout_sec = getValuePoint( valuestr, SOCK_TIMEOUT_SEC);	// Socket_Timeout
	m_socket_reconnect_sec = getValuePoint( valuestr, SOCK_RECONNECT_SEC);	// Recoonect_Sec
	if( m_socket_reconnect_sec < 0 ) m_socket_reconnect_sec = 0;
	if( m_socket_reconnect_sec > 300 ) m_socket_reconnect_sec = 300;

	m_storing_days		= getValuePoint( valuestr, STORE_DAYS);			// XML_Storing_Days
	m_send_wait_sec		= getValuePoint( valuestr, SEND_WAIT_SEC);		// Send_Wait_Sec
	if( m_send_wait_sec < 1 ){
		m_send_wait_sec = 1;
	}
	
	m_fail_by_socket_err = getValueString( valuestr, FAIL_BY_SOCKET_ERROR);		// Move record to fail folder after socket error

	m_xml_dir	= getValueString( valuestr, XML_DIR);					// XML_Directory
	m_workdir = m_xml_dir;
	m_workdir += "/work";
	m_faildir = m_xml_dir;
	m_faildir += "/fail";

	char databuf[8];
	string hl7data;
	// SOM_Charactor
	hl7data = getValueString( valuestr, SOM_CHAR );
	memset(databuf, 0, sizeof(databuf));
	if(hl7packet_ctrl_char(hl7data, databuf)){
		m_som_char = "SOM";
	}else{
		m_som_char = databuf;
	}
	// EOM_Charactor
	hl7data = getValueString( valuestr, EOM_CHAR );
	memset(databuf, 0, sizeof(databuf));
	if(hl7packet_ctrl_char(hl7data, databuf)){
		m_eom_char = "EOM";
	}else{
		m_eom_char = databuf;
	}
	//---------- [MSH Segment] ---------
	m_send_application	= getValueString( valuestr, SEND_APP);			// Sending_Applicaton
	m_send_facility		= getValueString( valuestr, SEND_FACILITY);		// Sending_Facility
	m_rcv_application	= getValueString( valuestr, RCV_APP);			// Receiving_Application
	m_rcv_facility		= getValueString( valuestr, RCV_FACILITY);		// Receiving_Facility
	m_accept_acknow		= getValueString( valuestr, ACCEPT_ACKNOW);		// Accept_Acknowledgment_Type
	m_app_acknow		= getValueString( valuestr, APP_ACKNOW);		// Application_Acknowledgment_Type
	m_country_code		= getValueString( valuestr, COUNTRY_CODE);		// Country_Code
	m_char_set			= getValueString( valuestr, CHAR_SET);			// Character_Set
	m_pri_language		= getValueString( valuestr, PRI_LANG);			// Principal_Language
	m_msg_profile_id	= getValueString( valuestr, MSG_PROFILE);		// Message_Profile_Identifier

	//---------- [PID Segment] ----------
	m_patient_id_list	= getValueString( valuestr, PAT_ID_LIST);		// Patient_ID_List
	m_patient_name		= getValueString( valuestr, PAT_NAME);			// Patient_Name
	m_inv_name			= getValueString( valuestr, INVERT_NAME);		// Invert Name
	//---------- [PV1 Segment] ----------
	m_pv1_seg			= getValueString( valuestr, PV1_SEG);			// PV1 Segment
	//---------- [ORC Segment] ----------
	m_orc_seg			= getValueString( valuestr, ORC_SEG);			// ORC Segment
	//---------- [OBR Segment] ----------
	m_filler_order_num	= getValueString( valuestr, FILL_ORDER_NUM);	// Filler_Order_Number
	m_univ_service_id	= getValueString( valuestr, UNIV_SERVICE_ID);	// Universal_Service_ID
	//---------- [TQ1 Segment] ----------
	m_tq1_seg			= getValueString( valuestr, TQ1_SEG);			// TQ1_Segment
	//---------- [TQ1 Segment] ----------
	m_ack_ignore_message_type = getValueString( valuestr, ACK_IGNORE_MESSAGE_TYPE);			// ACK

	//---------- Timezone string for each time data ----------
	m_no_timezone_str = getValueString( valuestr, NO_TIMEZONE_STR);			// Do not output timezone string?

	//---------- MDS/VMD/CHAN messages in OBX ----------
	m_mdsvmdchan = getValueString( valuestr, OBX_MDSVMDCHAN);			// Output MDS/VMD/CHAN OBX messages?
	
	//---------- MDS/VMD/CHAN messages in OBX ----------
	m_location = getValueString( valuestr, OBX_LOCATION);			// Output MDS/VMD/CHAN OBX messages?
	
	//---------- [OBX Segment] ----------
	// #Observation ID
	t_prminfo prminfo;
	char valuebuf[256];
	char logbuf[256];
	for(unsigned long i = 0; i < PRM_TBL_NUM; i++){
		memset( valuebuf, 0, sizeof( valuebuf ));
		prminfo.tag = prmTbl[i];
		//strcpy( valuebuf, prmTbl[i] );
		strcat(valuebuf, "\r");
		strcat(valuebuf, prmTbl[i]);
		strcat( valuebuf, "=" );

		prminfo.code = getValueString( valuestr, valuebuf );
		m_prmList.push_back( prminfo );
		
		sprintf(logbuf, " %d %s:%s", (int)i, m_prmList[i].tag.c_str(), m_prmList[i].code.c_str());
		logdat.trace_log( __func__, __LINE__, logbuf );
	}
	// #Units
	t_untinfo untinfo;
	unsigned int loc;
	for(unsigned long i = 0; i < UNT_TBL_NUM; i++){
		loc = valuestr.find( untTbl[i], 0 );
		if( loc != string::npos ) {
			memset( valuebuf, 0, sizeof( valuebuf ));
			for( int j = 0;; j++ ) {
				if( valuestr.at( loc + strlen( "Unit" ) + j ) == '=' ) {
					break;
				}
				valuebuf[j] = valuestr.at( loc + strlen( "Unit" ) + j );
			}
		}
		untinfo.id = atoi(valuebuf);
		
		memset( valuebuf, 0, sizeof( valuebuf ));
		strcpy( valuebuf, untTbl[i] );
		strcat( valuebuf, "=" );
		
		untinfo.name = getValueString( valuestr, valuebuf );
		m_untList.push_back( untinfo );

		sprintf(logbuf, " Unit%2d:%s", m_untList[i].id, m_untList[i].name.c_str());
		logdat.trace_log( __func__, __LINE__, logbuf );
	}
	
}


string confread::getValueString( string src, char *target )
{
	string retval;
	unsigned int loc = src.find( target, 0 );
	char valuebuf[256];
	if( loc != string::npos ) {
		memset( valuebuf, 0, sizeof( valuebuf ));
		for( int i = 0;; i++ ) {
			if( i == 256 ) break;
			if( src.at( loc + strlen( target ) + i ) == 0x0d ) {
				break;
			}
			valuebuf[i] = src.at( loc + strlen( target ) + i );
		}
		retval = valuebuf;
	}
	return retval;
}

int confread::getValuePoint( string src, char *target )
{
	int retval = 0;
	unsigned int loc = src.find( target, 0 );
	char valuebuf[80];
	if( loc != string::npos ) {
		memset( valuebuf, 0, sizeof( valuebuf ));
		for( int i = 0;; i++ ) {
			if( src.at( loc + strlen( target ) + i ) == 0x0d ) {
				break;
			}
			valuebuf[i] = src.at( loc + strlen( target ) + i );
		}
		retval = atoi( valuebuf );
	}
	return retval;
}
unsigned long confread::getValuePointUL( string src, char *target )
{
	unsigned long retval = 0;
	unsigned int loc = src.find( target, 0 );
	char valuebuf[80];
	if( loc != string::npos ) {
		memset( valuebuf, 0, sizeof( valuebuf ));
		for( int i = 0;; i++ ) {
			if( src.at( loc + strlen( target ) + i ) == 0x0d ) {
				break;
			}
			valuebuf[i] = src.at( loc + strlen( target ) + i );
		}
		retval = (unsigned long)strtoul( valuebuf , NULL, 10);
	}
	return retval;
}
long confread::getfilesize(char *f_name)
{
	struct stat filestat;
	
	int stat_err = stat( f_name, &filestat );
	if( stat_err != -1 ) {
		return filestat.st_size;
	}
	return 0;
}

void confread::comma_str2vector( string comma_str, vector<string>* dat )
{
	if( comma_str.length() <= 0 ) return;
	
	bool end_flg = false;
	unsigned int loc, pre_loc;
	string one_item;
	pre_loc = 0;
	while( !end_flg ) {
		loc = comma_str.find( ',', pre_loc );
		if( loc == string::npos ) {
			loc = comma_str.length();
			end_flg = true;
		}
		one_item = comma_str.substr( pre_loc, loc - pre_loc );
		dat->push_back( one_item );
		pre_loc = loc +1;
	}
}

int confread::hl7packet_ctrl_char( string read_str, char *dat )
{
	vector<string> str_vec;
	comma_str2vector( read_str, &str_vec );
	
	vector<string>::iterator pos;
	int i = 0;
	for( pos = str_vec.begin(); pos != str_vec.end(); ++pos ) {
		dat[i] = atoi( (*pos).c_str() );
		if( dat[i] == 0 || dat[0] == '\r' || !iscntrl( (int)dat[i] )) {
			return 1;
		}
		++i;
	}
	return 0;
}
/**************************************************************
* Function name: getPrmList ()
* Description: Set parameter list
* Argument std::vector <t_prmlist> * p_prmlist: Parameter list
* Return value: None
**************************************************************/
void confread::getPrmList( std::vector<t_prminfo> *p_prmlist )
{
	*p_prmlist = m_prmList;
}
/**************************************************************
* Function name: getUntList ()
* Description: Set unit list
* Argument std::vector <t_untinfo> * p_untlist: unit list
* Return value: None
**************************************************************/
void confread::getUntList( std::vector<t_untinfo> *p_untlist )
{
	*p_untlist = m_untList;
}
