rm -rf *.o

