#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> 
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>

#include "v_socket.h"

/**************************************************************
* Function name: v_socket ()
* Description: Constructor
* Arguments: None
* Return value: None
**************************************************************/
v_socket::v_socket()
{
	m_dstSocket = 0;
}
/**************************************************************
* Function name: v_socket ()
* Description: Constructor
* Arguments: int dstScoket: destination socket?
* Return value: None
**************************************************************/
v_socket::v_socket(int dstSocket)
{
	m_dstSocket = 0;
	m_dstSocket = dstSocket;
}
/**************************************************************
* Function name: sck_send2 ()
* Description: Send (connect and close each time you send)
* Argument: char * p_server_ip: Server IP
*     int server_port: Server port number
*     char * p_send_buf: transmission buffer
*     ssize_t send_size: transmission size
* Return value: ssize_t transmission size - 1: error
**************************************************************/
int v_socket::sck_send2(char *p_server_ip, int server_port, char *p_send_buf, ssize_t send_size)
{
	
	struct sockaddr_in dstAddr;
	int dstSocket=0;

	// set of sockaddr_in structure
	memset(&dstAddr, 0, sizeof(dstAddr));
	dstAddr.sin_port = htons(server_port);
	dstAddr.sin_family = AF_INET;
	dstAddr.sin_addr.s_addr = inet_addr(p_server_ip);

	// -------------------------------------------------- Socket generation ---
	dstSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(dstSocket < 0){
		return -1;
	}

	// --------------------------------------------------------- Connection ---
	if(connect(dstSocket, (struct sockaddr *) &dstAddr, sizeof(dstAddr)) < 0){
		return -1;
	}

	// --------------------------------------------------------------- Send ---
	long numBytesSend = 0, numBytesSendSum = 0;

	while (numBytesSendSum < send_size){
		// Send the production
		numBytesSend = send(dstSocket, (char *)p_send_buf + numBytesSendSum, send_size - numBytesSendSum, MSG_NOSIGNAL);

		// Sending error
		if(numBytesSend <= 0){
			// Close socket
			close(dstSocket);
			return -1;
		}
		numBytesSendSum += numBytesSend;
	}

	// ------------------------------------------------------- Close socket ---
	close(dstSocket);

	return 0;

}
/**************************************************************
* Function name: sck_connect ()
* Description: Connection
* Argument: char * p_server_ip: Server IP
*     int server_port: Server port number
* Return value: int Socket identifier
**************************************************************/
int v_socket::sck_connect(char *p_server_ip, int server_port)
{

	struct sockaddr_in dstAddr;
	m_dstSocket=0;

	// ------------------------------------------ set sockaddr_in structure ---
	memset(&dstAddr, 0, sizeof(dstAddr));
	dstAddr.sin_port = htons(server_port);
	dstAddr.sin_family = AF_INET;
	dstAddr.sin_addr.s_addr = inet_addr(p_server_ip);

	// -------------------------------------------------- Socket generation ---
	m_dstSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(m_dstSocket < 0){
		return -1;
	}

	// --------------------------------------------------------- Connection ---
	if(connect(m_dstSocket, (struct sockaddr *) &dstAddr, sizeof(dstAddr)) < 0){
		close(m_dstSocket);
		return -1;
	}
	return m_dstSocket;

}
/**************************************************************
* Function name: sck_close ()
* Description: Cut
* Arguments: int dstSocket: int dstSocket
* Return value: None
**************************************************************/
void v_socket::sck_close(int dstSocket)
{
	// ------------------------------------- Close socket ---
	if(dstSocket > 0){
		shutdown(dstSocket, 2);
		close(dstSocket);
	}

}
/**************************************************************
* Function name: sck_close ()
* Description: Cut
* Arguments: None
* Return value: None
**************************************************************/
void v_socket::sck_close()
{
	// ---------------------------------- Close socket ---
	if(m_dstSocket > 0){
		shutdown(m_dstSocket, 2);
		close(m_dstSocket);
		m_dstSocket = 0;
	}

}
/**************************************************************
* Function name: sck_server_close ()
* Description: Disconnect (for server process)
* Arguments: int dstSocket: int dstSocket
* Return value: None
**************************************************************/
void v_socket::sck_server_close(int dstSocket)
{
	// ---------------------------------- Close socket ---
	sck_timeout_check(dstSocket, 2); // timeout seconds fixed as 2 seconds fixed
	shutdown(dstSocket, 2);
	close(dstSocket);

}
/**************************************************************
* Function name: sck_server_close ()
* Description: Disconnect (for server process)
* Arguments: None
* Return value: None
**************************************************************/
void v_socket::sck_server_close()
{
	// ---------------------------------- Close socket ---
	sck_timeout_check(m_dstSocket, 2); // timeout seconds fixed as 2 seconds fixed
	if(m_dstSocket > 0){
		shutdown(m_dstSocket, 2);
		close(m_dstSocket);
		m_dstSocket = 0;
	}

}
/**************************************************************
* Function name: sck_send ()
* Description: Send
* Arguments: int dstSocket: Socket descriptor
*     char * p_send_buf: transmission buffer
*     ssize_t send_size: transmission size
* Return value: int 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_send(int dstSocket, void *p_send_buf, ssize_t send_size)
{

	// ------------------------------------------- Send ---
	long numBytesSend = 0, numBytesSendSum = 0;

	while (numBytesSendSum < send_size){
		// Send the production
		numBytesSend = send(dstSocket, (char *)p_send_buf + numBytesSendSum, send_size - numBytesSendSum, MSG_NOSIGNAL);

		// Sending error
		if(numBytesSend <= 0){
			// Close socket
			//close(dstSocket);
			return -1;
		}
		numBytesSendSum += numBytesSend;
	}

	return 0;

}
/**************************************************************
* Function name: sck_send ()
* Description: Send
* Arguments: int dstSocket: Socket descriptor
*     char * p_send_buf: transmission buffer
*     ssize_t send_size: transmission size
* Return value: int 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_send(void *p_send_buf, ssize_t send_size)
{

	// ------------------------------------------- Send ---
	long numBytesSend = 0, numBytesSendSum = 0;

	while (numBytesSendSum < send_size){
		//  Send the production
		numBytesSend = send(m_dstSocket, (char *)p_send_buf + numBytesSendSum, send_size - numBytesSendSum, MSG_NOSIGNAL);

		// Sending error
		if(numBytesSend <= 0){
			// Close socket
			//close(dstSocket);
			return -1;
		}
		numBytesSendSum += numBytesSend;
	}

	return 0;

}
/**************************************************************
* Function name: sck_recv ()
* Description: Receive
* Argument: int timeOutSec: Timeout in seconds
*     int dstSocket: socket descriptor
*     char * p_recv_buf: Receive buffer
*     ssize_t recv_size: Receive size
* Return value: int 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_recv(int timeOutSec, int dstSocket, void *p_recv_buf, ssize_t recv_size)
{

	// ------------------------------------------- Reception ---
	long numBytesRecv = 0, numBytesRecvSum = 0;

	while (numBytesRecvSum < recv_size){

		// timeout check
		if(sck_timeout_check(dstSocket, timeOutSec) < 0){
			char timeout_str[32];
			memset(timeout_str, 0, 32);
			sprintf(timeout_str, "!!ERR TIME OUT (%d SEC)!!", timeOutSec);
			m_err_message = timeout_str;
			return -1;
		}

		// receive
		numBytesRecv = recv(dstSocket, (char *)p_recv_buf + numBytesRecvSum, recv_size - numBytesRecvSum, 0);

		// receive error
		if(numBytesRecv <= 0){
			// Close socket
			//close(dstSocket);
			return -1;
		}
		numBytesRecvSum += numBytesRecv;
	}

	return 0;

}

/**************************************************************
* Function name: sck_recv ()
* Description: Receive
* Argument: int timeOutSec: Timeout in seconds
*     char * p_recv_buf: Receive buffer
*     ssize_t recv_size: Receive size
* Return value: int 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_recv(int timeOutSec, void *p_recv_buf, ssize_t recv_size)
{

	// ------------------------------------------- Reception ---
	long numBytesRecv = 0, numBytesRecvSum = 0;

	while (numBytesRecvSum < recv_size){

		// timeout check
		if(sck_timeout_check(m_dstSocket, timeOutSec) < 0){
			char timeout_str[32];
			memset(timeout_str, 0, 32);
			sprintf(timeout_str, "!!ERR TIME OUT (%d SEC)!!", timeOutSec);
			m_err_message = timeout_str;
			return -1;
		}

		// receive
		numBytesRecv = recv(m_dstSocket, (char *)p_recv_buf + numBytesRecvSum, recv_size - numBytesRecvSum, 0);

		// Receive error
		if(numBytesRecv <= 0){
			// Close socket
			//close(dstSocket);
			return -1;
		}
		numBytesRecvSum += numBytesRecv;
	}

	return 0;

}
/**************************************************************
* Function name: sck_recv_0x0D()
* Description: Receive (receive until EOD (0x0D) comes)
* Argument: int timeOutSec: Timeout in seconds
*     char * p_data: Receive buffer
* Return value: int 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_recv_0x0D(int timeOutSec, std::string *p_data)
{

	int numrcv;
	char buffer[RECV_BUFFER_SIZE];
	std::string findEOD ;

	// ------------------------------------------- Reception ---
	while(true ) {

		// timeout check
		if(sck_timeout_check(m_dstSocket, timeOutSec) < 0){
			char timeout_str[32];
			memset(timeout_str, 0, 32);
			sprintf(timeout_str, "!!ERR TIME OUT (%d SEC)!!", timeOutSec);
			m_err_message = timeout_str;
			m_err_message += " ";
			m_err_message += *p_data;
			sck_close();
			return -1;
		}

		// receive
		numrcv = recv(m_dstSocket, buffer, RECV_BUFFER_SIZE-1, 0); 
		if(numrcv == 0 || numrcv == -1) {
			m_err_message = "!!ERR RECV or CLIENT CLOSE!!";
			return -1;
		}

		// Null check
		for(int i=0; i<numrcv; i++){
			if(buffer[i] == 0){
				m_err_message = "!!ERR RECV NULL!!";
				return -1;
			}
		}

		buffer[numrcv] = 0;
		*p_data += buffer;
		findEOD += buffer;

		std::string::size_type loc = findEOD.find("\r", 0);
		if(loc != std::string::npos){
			return 0;
		}
	}

	return 0;

}
/**************************************************************
* Function name: sck_recv_eom ()
* Description: Receive (receive until eom comes)
* Argument: int timeOutSec: Timeout in seconds
*     char * p_data: Receive buffer
*     char * p_eom: eom
* Return value: int 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_recv_eom(int timeOutSec, std::string *p_data, const char *p_eom)
{

	int numrcv;
	char buffer[RECV_BUFFER_SIZE];
	std::string findEOM ;

	// ------------------------------------------- Reception ---
	while(true ) {

		// timeout check
		if(sck_timeout_check(m_dstSocket, timeOutSec) < 0){
			char timeout_str[32];
			memset(timeout_str, 0, 32);
			sprintf(timeout_str, "!!ERR TIME OUT (%d SEC)!!", timeOutSec);
			m_err_message = timeout_str;
			m_err_message += " ";
			m_err_message += *p_data;
			sck_close();
			return -1;
		}

		// receive
		numrcv = recv(m_dstSocket, buffer, RECV_BUFFER_SIZE-1, 0);
		if(numrcv == 0 || numrcv == -1) {
			m_err_message = "!!ERR RECV or CLIENT CLOSE!!";
			return -1;
		}

		// Null check
		for(int i=0; i<numrcv; i++){
			if(buffer[i] == 0){
				m_err_message = "!!ERR RECV NULL!!";
				return -1;
			}
		}

		buffer[numrcv] = 0;
		*p_data += buffer;
		findEOM += buffer;

		std::string::size_type loc = findEOM.find(p_eom, 0);
		if(loc != std::string::npos){
			return 0;
		}
	}

	return 0;

}

/**************************************************************
* Function name: sck_timeout_check ()
* Description: Confirmation of timeout
* Argument: int dstSocket: Socket descriptor t
*     int timeOutSec: Timeout in seconds
* Return value: 0: Normal - 1: Timeout
**************************************************************/
int v_socket::sck_timeout_check(int dstSocket, long time_sec)
{
	fd_set fds;
	struct timeval timeout;
	FD_ZERO(&fds);
	FD_SET(dstSocket, &fds);
	timeout.tv_sec = time_sec;
	timeout.tv_usec = 0;

	while(true){
		if ( select(dstSocket + 1, &fds, NULL, NULL, &timeout ) == -1 ){
			return -1;
		}

		if ( FD_ISSET(dstSocket, &fds) == 0){
			return -1;
		}else{
			return 0;
		}
	}

	return 0;

}
/**************************************************************
* Function name: sck_timeout_check ()
* Description: Confirmation of timeout
* Argument: int dstSocket: Socket descriptor t
*     int timeOutSec: Timeout in seconds
* Return value: 0: Normal - 1: Timeout
**************************************************************/
int v_socket::sck_timeout_check(long time_sec)
{
	fd_set fds;
	struct timeval timeout;
	FD_ZERO(&fds);
	FD_SET(m_dstSocket, &fds);
	timeout.tv_sec = time_sec;
	timeout.tv_usec = 0;

	while(true){
		if ( select(m_dstSocket + 1, &fds, NULL, NULL, &timeout ) == -1 ){
			return -1;
		}

		if ( FD_ISSET(m_dstSocket, &fds) == 0){
			return -1;
		}else{
			return 0;
		}
	}

	return 0;

}
/**************************************************************
* Function name: sck_listen ()
* Description: Socket reception preparation
* Argument: int listenPort: port number
* Return value: 0: Normal - 1: Error
**************************************************************/
int v_socket::sck_listen(int listenPort)
{

	// ----------------------- Socket creation (socket) ---
	if(( m_dstSocket = socket( AF_INET, SOCK_STREAM, 0 )) < 0 ) { 
		return -1;
	}

	// --------------------------- Socket naming (bind) ---
	struct sockaddr_in serverAddr;
	serverAddr.sin_family      = AF_INET;
	serverAddr.sin_addr.s_addr = INADDR_ANY;
	serverAddr.sin_port        = htons( listenPort );

	if( bind( m_dstSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr) ) < 0 ) {
		std::cout << "bind(NG:%d):" << errno << "\n";
		close(m_dstSocket);
		return -1;
	}

	// --- Preparation to accept connection request (listen)---
	if( listen( m_dstSocket, 1)  < 0 ){
		std::cout << "listen(NG:%d):" << errno << "\n";
		close(m_dstSocket);
		return -1;
	}

	return 0;
}

/**************************************************************
* Function name: sck_accept ()
* Description: Permit connection request
* Arguments: struct sockaddr * addr: Address structure pointer
*     socklen_t * addrlen: Address structure size
* Return value: 0: Socket identifier -1: Error
**************************************************************/
int v_socket::sck_accept(struct sockaddr *addr, socklen_t *addrlen)
{

	int dstSocket = 0;

	// --------------------- Permit connection request (accept) ---
	dstSocket = accept(m_dstSocket, addr, addrlen);

	return dstSocket;
}

/**************************************************************
* Function name: GetPackMessage ()
* Description: Acquire packets on the nearest transmission / reception
* Arguments: None
* Return value: Packets sent and received
**************************************************************/
std::string v_socket::GetPackMessage()
{

	return m_pack_message;
}
/**************************************************************
* Function name: GetErrMessage ()
* Description: Get the error message on the last page
* Arguments: None
* Return value: Error message
**************************************************************/
std::string v_socket::GetErrMessage()
{

	return m_err_message;
}
