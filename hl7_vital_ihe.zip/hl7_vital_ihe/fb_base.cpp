
#include "prg_cmn.h"
#include "fb_base.h"

#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

firebird_base::firebird_base( void )
{
	DB = NULL;
}

firebird_base::~firebird_base( void )
{
	db_disconnect( NULL, NULL );
	DB = NULL;
}

int firebird_base::getSqlerrno( ISC_STATUS_ARRAY* sts, char* errmsg, size_t size_errmsg )
{
	long* pvector;
	if( errmsg ) {
		pvector = (long*)*sts;
#if defined FB_API_VER && FB_API_VER >= 20
		fb_interpret( errmsg, size_errmsg, (const ISC_STATUS**)&pvector );
#else
		isc_interprete( errmsg, &pvector );
#endif
	}
#if 1
	else {
		char errtrace[512];
		pvector = (long*)*sts;
#if defined FB_API_VER && FB_API_VER >= 20
		fb_interpret( errtrace, sizeof(errtrace), (const ISC_STATUS**)&pvector );
#else
		isc_interprete( errtrace, &pvector );
#endif

//		job_log(errtrace);

//		write_log( errtrace );
//		cout << "[" << errtrace << "]\n";
	}
#endif
	return isc_sqlcode( *sts );
}

int firebird_base::db_connect( string svnm, isc_tr_handle* tr, isc_stmt_handle* st, int noflg )
{
	DB = NULL;
	char dpb_buf[256];
	memset( dpb_buf, 0x00, sizeof(dpb_buf) );
	
	int i = 0;
	dpb_buf[i++] = isc_dpb_version1;
	dpb_buf[i++] = isc_dpb_user_name;
	int len = (int)strlen( CVWDB_USER );
	dpb_buf[i++] = (char)len;
	memcpy( &(dpb_buf[i]), CVWDB_USER, len );
	i += len;
	
	dpb_buf[i++] = isc_dpb_password;
	len = (int)strlen( CVWDB_PASSWD );
	dpb_buf[i++] = (char)len;
	memcpy( &(dpb_buf[i]), CVWDB_PASSWD, len );
	i += len;
	
	ISC_STATUS_ARRAY status;
	int err;
	err = isc_attach_database( status,
			0,
			(char*)svnm.c_str(),
			&DB,
			i,
			dpb_buf );
	if( status[0] == 1 && status[1] ) {
		DB = NULL;
		return getSqlerrno( &status );
	}
	
	if( DB_NOTRAN & noflg ) {
		return err;
	}
	
	if( DB_UPDTTRAN & noflg ) {
		err = update_transaction( tr );
	}
	else {
		err = read_transaction( tr );
	}
	if( 0 != err ) return err;
	
	if( !(DB_NOALLOCATE & noflg)) {
		err = allocate_statement( st );
		if( 0 != err ) return err;
	}
	
	return err;
}

int firebird_base::read_transaction( isc_tr_handle* tr )
{
	static char isc_tpb[] = {
		  isc_tpb_version3
		, isc_tpb_read
		, isc_tpb_concurrency
		};
	ISC_STATUS_ARRAY status;
	isc_start_transaction( status, tr, 1, &DB, (unsigned short)sizeof(isc_tpb), isc_tpb );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

int firebird_base::update_transaction( isc_tr_handle* tr )
{
	ISC_STATUS_ARRAY status;
	isc_start_transaction( status, tr, 1, &DB, 0, NULL );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

int firebird_base::commit_transaction( isc_tr_handle* tr )
{
	ISC_STATUS_ARRAY status;
	isc_commit_transaction( status, tr );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

int firebird_base::retainig_transaction( isc_tr_handle* tr )
{
	ISC_STATUS_ARRAY status;
	isc_commit_retaining( status, tr );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

int firebird_base::rollback_transaction( isc_tr_handle* tr )
{
	ISC_STATUS_ARRAY status;
	isc_rollback_transaction( status, tr );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

int firebird_base::allocate_statement( isc_stmt_handle* st )
{
	ISC_STATUS_ARRAY status;
	isc_dsql_allocate_statement( status, &DB, st );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

int firebird_base::free_statement( isc_stmt_handle* st )
{
	ISC_STATUS_ARRAY status;
	isc_dsql_free_statement( status, st, DSQL_drop );
	if( status[0] == 1 && status[1] ) {
		return getSqlerrno( &status );
	}
	return 0;
}

void firebird_base::db_disconnect( isc_tr_handle* tr, isc_stmt_handle* st )
{
	ISC_STATUS_ARRAY status;
	if( st ) {
		free_statement( st );
		*st = NULL;
	}
	if( tr ) {
		commit_transaction( tr );
		*tr = NULL;
	}
	if( DB ) {
		isc_detach_database( status, &DB );
		if( status[0] == 1 && status[1] ){
			isc_print_status( status );
		}
		
		DB = NULL;
	}
}

int firebird_base::db_prepare( isc_tr_handle* tr, isc_stmt_handle* st, string sql, XSQLDA* sqlda, unsigned short diarect )
{
	ISC_STATUS_ARRAY status;
	if( 0 != isc_dsql_prepare( status, tr, st, 0, (char*)sql.c_str(), diarect, sqlda )) {
//		char buf[256];
//		getSqlerrno( &status, buf );
//		cout << buf << "\n";
		return -1;
	}
	return 0;
}

int firebird_base::executeSql( string sqlstr, isc_tr_handle* tr, unsigned short diarect )
{
	isc_stmt_handle stmt = NULL;
	ISC_STATUS_ARRAY status;
	allocate_statement( &stmt );
	int ret = isc_dsql_execute_immediate( status, &DB, tr, 0, (char*)sqlstr.c_str(), diarect, NULL );
	if( ret ) {
		getSqlerrno( &status );
	}
	free_statement( &stmt );
	return ret;
}

// If fb_tmstmp is NULL, the return value is -1
time_t firebird_base::fbtime2time_t( ISC_TIMESTAMP* fb_tmstmp )
{
	struct tm tmbuf;
	time_t val = -1;
	
	if( fb_tmstmp->timestamp_date != 0 ) {
		isc_decode_timestamp( fb_tmstmp, &tmbuf );
		val = mktime( &tmbuf );
	}
	return val;
}

/******* Private definition (common with tools.h)***********************/
#define		YEAR		0
#define		MONTH		1
#define		DAY			2
#define		HOUR		3
#define		MINUTE	 	4
#define		SECOND		5
int firebird_base::fbtime2timebeans( ISC_TIMESTAMP* fb_tmstmp ,short* ymdhms )
{
	struct tm tmbuf;
	int val = -1;
	
	if( fb_tmstmp->timestamp_date != 0 ) {
		isc_decode_timestamp( fb_tmstmp, &tmbuf );
		ymdhms[YEAR] = tmbuf.tm_year + 1900;
		ymdhms[MONTH] = tmbuf.tm_mon + 1;
		ymdhms[DAY] = tmbuf.tm_mday;
		ymdhms[HOUR] = tmbuf.tm_hour;
		ymdhms[MINUTE] = tmbuf.tm_min;
		ymdhms[SECOND] = tmbuf.tm_sec;
		val = 0;
	}
	else {
		ymdhms[YEAR] = -1;
		ymdhms[MONTH] = -1;
		ymdhms[DAY] = -1;
		ymdhms[HOUR] = -1;
		ymdhms[MINUTE] = -1;
		ymdhms[SECOND] = -1;
	}
	return val;
}


XSQLDA* firebird_base::xsqlda_malloc( int fld_cnt )
{
	XSQLDA* adr = (XSQLDA *)malloc( XSQLDA_LENGTH( fld_cnt ));
	adr->sqln = fld_cnt;
	adr->sqld = fld_cnt;
	adr->version = 1;
	return adr;
}

void firebird_base::xsqvar_set( XSQLVAR* xvar, char* data, short type, short len, short* ind )
{
	xvar->sqldata = data;
	xvar->sqltype = type;
	xvar->sqllen = len;
	xvar->sqlind = ind;
}

int firebird_base::execute_isql( isc_tr_handle* tr, isc_stmt_handle* st )
{
	ISC_STATUS_ARRAY status;
	int ret = isc_dsql_execute( status, tr, st, 1, NULL );
	if( ret ) {
		getSqlerrno( &status );
	}
	return ret;
}
