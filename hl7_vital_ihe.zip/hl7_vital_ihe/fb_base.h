


#ifndef _CLASS_FIREBIED_BASE
#define _CLASS_FIREBIED_BASE

#include "logwrite.h"

// 

// noflg flag for db_connect
#define DB_NOALLOCATE		0x01			// Do not execute ALLOCATE (when executing ExecuteSQL consecutively)
#define DB_UPDTTRAN			0x02			// Transaction open for UPDATE. Unspecified, read-only transaction
#define DB_NOTRAN			0x04			// Do not prepare transaction

class firebird_base //: public logwrite
{
public:
	firebird_base( char *exename );
	firebird_base( void );
	~firebird_base( void );
	
protected:
	int getSqlerrno( ISC_STATUS_ARRAY* sts, char* errmsg = NULL, size_t size_errmsg = 0 );
	int db_connect( string svnm, isc_tr_handle* tr, isc_stmt_handle* st, int noflg = 0 );
	void db_disconnect( isc_tr_handle* tr, isc_stmt_handle* st );
	int db_prepare( isc_tr_handle* tr, isc_stmt_handle* st, string sql, XSQLDA* sqlda, unsigned short diarect = 1 );
	int executeSql( string sqlstr, isc_tr_handle* tr, unsigned short diarect = 1 );
	int allocate_statement( isc_stmt_handle* st );
	int free_statement( isc_stmt_handle* st );
	
	int read_transaction( isc_tr_handle* tr );
	int commit_transaction( isc_tr_handle* tr );
	int rollback_transaction( isc_tr_handle* tr );
	int update_transaction( isc_tr_handle* tr );
	int retainig_transaction( isc_tr_handle* tr );
	
	time_t fbtime2time_t( ISC_TIMESTAMP* fb_tmstmp );
	int fbtime2timebeans( ISC_TIMESTAMP* fb_tmstmp ,short* ymdhms );
	XSQLDA* xsqlda_malloc( int fld_cnt );
	void xsqvar_set( XSQLVAR* xvar, char* data, short type, short len, short* ind );
	int execute_isql( isc_tr_handle* tr, isc_stmt_handle* st );
	
	isc_db_handle DB;
};

#endif // _CLASS_FIREBIED_BASE
