#ifndef _CLASS_CONFREAD
#define _CLASS_CONFREAD

#include <vector>
using namespace std;
// -------------------------------------
//   define
// -------------------------------------
#define CNF_PUBDB 				"CONNECT_DATABASE"
#define CNF_MODE "MODE"
#define CONF_DEFAULT_SEND_APP	"FD-DYNABASE"
#define CONF_DEFAULT_SEND_APP	"FD-DYNABASE"
#define CONF_DEFAULT_RCV_APP	"HIS"
#define CONF_DEFAULT_PRI_LANG	"EN^English^ISO659"

//Common
#define DEST_HOST			"Destination_Host="
#define DEST_PORT			"Destination_Port="
#define SOCK_TIMEOUT_SEC	"Socket_Timeout_Sec="
#define SOCK_RECONNECT_SEC	"Reconnect_Sec="		// reconnect after socket error in sec
#define STORE_DAYS			"XML_Storing_Days="
#define SOM_CHAR			"SOM_Charactor="
#define EOM_CHAR			"EOM_Charactor="
#define SEND_WAIT_SEC		"Send_Wait_Sec="
#define FAIL_BY_SOCKET_ERROR	"Move_To_Fail_By_Socket_Error="
#define XML_DIR				"XML_Directory="
// MSH Segment
#define SEND_APP			"Sending_Application="
#define SEND_FACILITY		"Sending_Facility="
#define RCV_APP				"Receiving_Application="
#define RCV_FACILITY		"Receiving_Facility="
#define ACCEPT_ACKNOW		"Accept_Acknowledgment_Type="
#define APP_ACKNOW			"Application_Acknowledgment_Type="
#define COUNTRY_CODE		"Country_Code="
#define CHAR_SET			"Character_Set="
#define PRI_LANG			"Principal_Language="
#define MSG_PROFILE			"Message_Profile_Identifier="
// PID Segment
#define PAT_ID_LIST			"Patient_ID_List="
#define PAT_NAME			"Patient_Name="
#define INVERT_NAME			"Invert_Name="
// PV1 Segment
#define PV1_SEG				"PV1_Segment="
// ORC Segment
#define ORC_SEG				"ORC_Segment="
// OBR Segment
#define FILL_ORDER_NUM		"Filler_Order_Number="
#define UNIV_SERVICE_ID		"Universal_Service_ID="
// TQ1 Segment
#define TQ1_SEG				"TQ1_Segment="
// ACK^R01
#define ACK_IGNORE_MESSAGE_TYPE		"ACK_Ignore_Message_Type="
// ACK^R01
#define NO_TIMEZONE_STR		"No_Timezone_Str="
// OBX MDS/VMD/CHAN
#define OBX_MDSVMDCHAN		"OBX_MDSVMDCHAN="
// OBX Location Infroamtion
#define OBX_LOCATION		"OBX_Location="



// -------------------------------------
//   struct
// -------------------------------------
// Parameter
struct t_prminfo {
	string tag;
	string code;
};
struct t_fl_bumoninfo {
	int id;
	int interval;
};
// Units
struct t_untinfo {
	int id;
	string name;
};

class confread
{
public:
	confread( const char *exe_name );
	void vitalConf();

	int m_data_sort;

	//Common
	string m_pub_database;
	string m_ds_adt_mode;
	string m_destination_host;
	int m_destination_port;
	int m_socket_timeout_sec;
	int m_socket_reconnect_sec;
	int m_storing_days;
	string m_som_char;
	string m_eom_char;
	int m_send_wait_sec;
	string m_fail_by_socket_err;
	string m_xml_dir;
	string m_workdir;
	string m_faildir;

	// MSH Segment
	string m_send_application;
	string m_send_facility;
	string m_rcv_application;
	string m_rcv_facility;
	string m_accept_acknow;
	string m_app_acknow;
	string m_country_code;
	string m_char_set;
	string m_pri_language;
	string m_msg_profile_id;

	// PID Segment
	string m_patient_id_list;
	string m_patient_name;
	string m_inv_name;

	// PV1 Segment
	string m_pv1_seg;

	// ORC Segment
	string m_orc_seg;

	// OBR Segment
	string m_filler_order_num;
	string m_univ_service_id;

	// TQ1 Segment
	string m_tq1_seg;

	// OBX Segment
	vector<t_prminfo> m_prmList;
	vector<t_untinfo> m_untList;
	
	// ACK^R01
	string m_ack_ignore_message_type;
	
	// No timezone string?
	string m_no_timezone_str;
	// OBX MDS/VMD/CHAN
	string m_mdsvmdchan;
	// OBX Location
	string m_location;
	
	void getPrmList(vector<t_prminfo> *p_prmlist);
	void getUntList(vector<t_untinfo> *p_untlist);

	char m_conf_path[256];
	char m_exe_name[64];
private:
	long getfilesize(char *f_name);
	string getValueString( string src, char *target );
	int getValuePoint( string src, char *target );
	unsigned long getValuePointUL( string src, char *target );

	void comma_str2vector( string comma_str, vector<string>* dat );
	int hl7packet_ctrl_char( string read_str, char *dat );

};

#endif // _CLASS_CONFREAD
