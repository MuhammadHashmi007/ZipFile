
#ifndef _CLASS_V_SOCKET
#define _CLASS_V_SOCKET

#define RECV_BUFFER_SIZE          (160000)

#include <sys/socket.h>
class v_socket 
{
public:
	v_socket();
	v_socket(int dstSocket);
	int m_dstSocket;

	int sck_send2(  char *p_server_ip, int server_port, char *p_send_buf, ssize_t send_size );
	int sck_connect(char *p_server_ip, int server_port);


	int sck_listen(int listenPort);
	int sck_accept(struct sockaddr *addr, socklen_t *addrlen);
	int sck_send(void *p_send_buf, ssize_t send_size);
	int sck_recv(int timeOutSec, void *p_recv_buf, ssize_t recv_size);
	int sck_timeout_check(long time_sec);
	void sck_close();
	void sck_server_close();

	int sck_recv_0x0D(int timeOutSec, std::string *p_data);
	int sck_recv_eom(int timeOutSec, std::string *p_data, const char *p_eom);

	int sck_send(int dstSocket, void *p_send_buf, ssize_t send_size);
	int sck_recv(int timeOutSec, int dstSocket, void *p_recv_buf, ssize_t recv_size);
	int sck_timeout_check(int dstSocket, long time_sec);
	void sck_close(int dstSocket);
	void sck_server_close(int dstSocket);

	std::string GetPackMessage();
	std::string GetErrMessage();

private:
	int m_log_lovel;
	std::string m_pack_message;
	std::string m_err_message;
};


#endif // _CLASS_LOGWRITE
